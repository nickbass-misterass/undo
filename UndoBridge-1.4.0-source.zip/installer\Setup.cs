// Undo Bridge — установщик дополнения для Яндекс.Браузера / Chrome / Edge.
// Компилируется csc.exe из .NET Framework 4.x, без внешних зависимостей.
//
// Что делает установщик:
//   1. распаковывает дополнение в %LOCALAPPDATA%\UndoBridge\extension;
//   2. собирает подписанный CRX3 и прописывает его в реестр браузера (best effort);
//   3. открывает страницу дополнений и кладёт путь в буфер обмена;
//   4. показывает пошаговую инструкцию и умеет проверить результат.

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.IO.Compression;
using System.Reflection;
using System.Security.Cryptography;
using System.Text;
using System.Windows.Forms;
using Microsoft.Win32;

namespace UndoBridgeSetup
{
    public class BrowserInfo
    {
        public string Name;          // отображаемое имя
        public string VendorKey;     // Software\<VendorKey>\Extensions
        public string[] ExePaths;    // где искать исполняемый файл
        public string ExePath;       // найденный путь (null если нет)
        public string ExtPage;       // внутренняя страница дополнений
        public string UserDataDir;   // профиль браузера (для проверки установки)
        public bool Selected;

        public bool Found { get { return !String.IsNullOrEmpty(ExePath); } }
    }

    public class SetupForm : Form
    {
        /* ---------------- состояние ---------------- */

        readonly string targetDir = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "UndoBridge");
        string extDir { get { return Path.Combine(targetDir, "extension"); } }
        string agentDir { get { return Path.Combine(targetDir, "agent"); } }
        string agentExe { get { return Path.Combine(agentDir, "UndoBridgeAgent.exe"); } }
        string crxPath { get { return Path.Combine(targetDir, "undobridge.crx"); } }
        string keyPath { get { return Path.Combine(targetDir, "extension-key.xml"); } }

        List<BrowserInfo> browsers = new List<BrowserInfo>();
        List<BrowserInfo> installed = new List<BrowserInfo>();
        List<CheckBox> boxes = new List<CheckBox>();
        TextBox log;
        CheckBox optOpenPage, optClipboard, optShortcut, optAutostart;

        Panel stepsPanel;
        Label stepsTitle, stepsText;
        Button btnOpenPage, btnCopyPath, btnCheckSteps;

        string extId = "";
        bool silent = false;

        /* ---------------- окно ---------------- */

        public SetupForm()
        {
            Text = "Undo Bridge — установка дополнения";
            ClientSize = new Size(620, 686);
            FormBorderStyle = FormBorderStyle.FixedSingle;
            MaximizeBox = false;
            StartPosition = FormStartPosition.CenterScreen;
            BackColor = Color.FromArgb(13, 17, 23);
            ForeColor = Color.FromArgb(215, 230, 222);
            Font = new Font("Segoe UI", 9f);

            Label title = new Label();
            title.Text = "UNDO BRIDGE";
            title.Font = new Font("Consolas", 16f, FontStyle.Bold);
            title.ForeColor = Color.FromArgb(46, 204, 113);
            title.SetBounds(16, 12, 400, 28);
            Controls.Add(title);

            Label sub = new Label();
            sub.Text = "Undo ставится как фоновый движок без окна, а весь интерфейс —\n" +
                       "в дополнении браузера: панель на странице и полное окно в боковой панели.";
            sub.ForeColor = Color.FromArgb(138, 154, 165);
            sub.SetBounds(16, 42, 586, 38);
            Controls.Add(sub);

            GroupBox gbBrowser = new GroupBox();
            gbBrowser.Text = " 1. Куда установить (можно несколько) ";
            gbBrowser.ForeColor = Color.FromArgb(215, 230, 222);
            gbBrowser.SetBounds(16, 84, 586, 124);
            Controls.Add(gbBrowser);

            FindBrowsers();
            int idx = 0;
            foreach (BrowserInfo b in browsers)
            {
                CheckBox cb = new CheckBox();
                cb.Text = b.Name + (b.Found ? "" : "  — нет");
                cb.Checked = b.Found;
                cb.Enabled = b.Found;
                cb.Tag = b;
                int col = idx / 4;
                int row = idx % 4;
                cb.SetBounds(14 + col * 288, 18 + row * 25, 282, 22);
                cb.ForeColor = b.Found ? Color.FromArgb(215, 230, 222) : Color.FromArgb(120, 130, 138);
                gbBrowser.Controls.Add(cb);
                boxes.Add(cb);
                idx++;
            }

            GroupBox gbOpt = new GroupBox();
            gbOpt.Text = " 2. Параметры ";
            gbOpt.ForeColor = Color.FromArgb(215, 230, 222);
            gbOpt.SetBounds(16, 218, 586, 112);
            Controls.Add(gbOpt);

            optOpenPage = MakeOption(gbOpt, "Открыть страницу дополнений сразу после установки", 20, true);
            optClipboard = MakeOption(gbOpt, "Скопировать путь к папке дополнения в буфер обмена", 42, true);
            optShortcut = MakeOption(gbOpt, "Создать на рабочем столе ярлык «DeepSeek + Undo»", 64, true);
            optAutostart = MakeOption(gbOpt, "Запускать Undo в фоне при входе в Windows", 86, true);

            Button btnInstall = new Button();
            btnInstall.Text = "УСТАНОВИТЬ";
            btnInstall.Font = new Font("Consolas", 11f, FontStyle.Bold);
            btnInstall.SetBounds(16, 340, 226, 44);
            btnInstall.Click += OnInstall;
            Controls.Add(btnInstall);

            Button btnCheck = new Button();
            btnCheck.Text = "Проверить";
            btnCheck.SetBounds(250, 340, 158, 44);
            btnCheck.Click += OnCheck;
            Controls.Add(btnCheck);

            Button btnClose = new Button();
            btnClose.Text = "Закрыть";
            btnClose.SetBounds(416, 340, 186, 44);
            btnClose.Click += delegate { Close(); };
            Controls.Add(btnClose);

            /* панель с шагами: появляется после установки */
            stepsPanel = new Panel();
            stepsPanel.SetBounds(16, 394, 586, 154);
            stepsPanel.BackColor = Color.FromArgb(17, 26, 32);
            stepsPanel.BorderStyle = BorderStyle.FixedSingle;
            stepsPanel.Visible = false;
            Controls.Add(stepsPanel);

            stepsTitle = new Label();
            stepsTitle.SetBounds(12, 8, 560, 20);
            stepsTitle.Font = new Font("Consolas", 9.5f, FontStyle.Bold);
            stepsTitle.ForeColor = Color.FromArgb(46, 204, 113);
            stepsPanel.Controls.Add(stepsTitle);

            stepsText = new Label();
            stepsText.SetBounds(12, 30, 560, 78);
            stepsText.ForeColor = Color.FromArgb(200, 214, 208);
            stepsPanel.Controls.Add(stepsText);

            btnOpenPage = MakeStepButton(stepsPanel, "Открыть дополнения", 12, 112, 186, OnOpenPage);
            btnCopyPath = MakeStepButton(stepsPanel, "Скопировать путь", 206, 112, 178, OnCopyPath);
            btnCheckSteps = MakeStepButton(stepsPanel, "Проверить установку", 392, 112, 182, OnCheck);

            log = new TextBox();
            log.Multiline = true;
            log.ReadOnly = true;
            log.ScrollBars = ScrollBars.Vertical;
            log.SetBounds(16, 558, 586, 112);
            log.BackColor = Color.FromArgb(10, 15, 19);
            log.ForeColor = Color.FromArgb(160, 190, 175);
            log.Font = new Font("Consolas", 8.5f);
            log.BorderStyle = BorderStyle.FixedSingle;
            Controls.Add(log);

            Say("Найдено браузеров: " + CountFound() + ". Выберите и нажмите «Установить».");
        }

        CheckBox MakeOption(GroupBox parent, string text, int y, bool value)
        {
            CheckBox cb = new CheckBox();
            cb.Text = text;
            cb.Checked = value;
            cb.SetBounds(14, y, 556, 22);
            cb.ForeColor = Color.FromArgb(215, 230, 222);
            parent.Controls.Add(cb);
            return cb;
        }

        Button MakeStepButton(Panel parent, string text, int x, int y, int w, EventHandler click)
        {
            Button b = new Button();
            b.Text = text;
            b.SetBounds(x, y, w, 30);
            b.Click += click;
            parent.Controls.Add(b);
            return b;
        }

        int CountFound()
        {
            int n = 0;
            foreach (BrowserInfo b in browsers) { if (b.Found) n++; }
            return n;
        }

        void Say(string s)
        {
            if (log == null) return;
            log.AppendText("> " + s + Environment.NewLine);
            try { log.SelectionStart = log.TextLength; log.ScrollToCaret(); } catch { }
        }

        /* ---------------- поиск браузеров ---------------- */

        void FindBrowsers()
        {
            browsers.Clear();

            string local = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
            string pf = Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles);
            string pf86 = Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86);

            BrowserInfo chrome = new BrowserInfo();
            chrome.Name = "Google Chrome";
            chrome.VendorKey = @"Software\Google\Chrome";
            chrome.ExtPage = "chrome://extensions/";
            chrome.UserDataDir = Path.Combine(local, @"Google\Chrome\User Data");
            chrome.ExePaths = new string[] {
                Combine(pf, @"Google\Chrome\Application\chrome.exe"),
                Combine(pf86, @"Google\Chrome\Application\chrome.exe"),
                Combine(local, @"Google\Chrome\Application\chrome.exe")
            };
            browsers.Add(chrome);

            BrowserInfo yandex = new BrowserInfo();
            yandex.Name = "Яндекс.Браузер";
            yandex.VendorKey = @"Software\Yandex\YandexBrowser";
            yandex.ExtPage = "browser://extensions/";
            yandex.UserDataDir = Path.Combine(local, @"Yandex\YandexBrowser\User Data");
            yandex.ExePaths = new string[] {
                Combine(pf, @"Yandex\YandexBrowser\Application\browser.exe"),
                Combine(pf86, @"Yandex\YandexBrowser\Application\browser.exe"),
                Combine(local, @"Yandex\YandexBrowser\Application\browser.exe")
            };
            browsers.Add(yandex);

            BrowserInfo edge = new BrowserInfo();
            edge.Name = "Microsoft Edge";
            edge.VendorKey = @"Software\Microsoft\Edge";
            edge.ExtPage = "edge://extensions/";
            edge.UserDataDir = Path.Combine(local, @"Microsoft\Edge\User Data");
            edge.ExePaths = new string[] {
                Combine(pf86, @"Microsoft\Edge\Application\msedge.exe"),
                Combine(pf, @"Microsoft\Edge\Application\msedge.exe")
            };
            browsers.Add(edge);

            BrowserInfo opera = new BrowserInfo();
            opera.Name = "Opera";
            opera.VendorKey = @"Software\Opera Software\OperaStable";
            opera.ExtPage = "opera://extensions/";
            opera.UserDataDir = Path.Combine(local, @"Opera Software\Opera Stable");
            opera.ExePaths = new string[] {
                Combine(local, @"Programs\Opera\launcher.exe"),
                Combine(pf, @"Opera\launcher.exe"),
                Combine(pf86, @"Opera\launcher.exe"),
                Combine(local, @"Programs\Opera\opera.exe")
            };
            browsers.Add(opera);

            BrowserInfo operaGx = new BrowserInfo();
            operaGx.Name = "Opera GX";
            operaGx.VendorKey = @"Software\Opera Software\OperaGXStable";
            operaGx.ExtPage = "opera://extensions/";
            operaGx.UserDataDir = Path.Combine(local, @"Opera Software\Opera GX Stable");
            operaGx.ExePaths = new string[] {
                Combine(local, @"Programs\Opera GX\launcher.exe"),
                Combine(pf, @"Opera GX\launcher.exe"),
                Combine(local, @"Programs\Opera GX\opera.exe")
            };
            browsers.Add(operaGx);

            BrowserInfo brave = new BrowserInfo();
            brave.Name = "Brave";
            brave.VendorKey = @"Software\BraveSoftware\Brave-Browser";
            brave.ExtPage = "brave://extensions/";
            brave.UserDataDir = Path.Combine(local, @"BraveSoftware\Brave-Browser\User Data");
            brave.ExePaths = new string[] {
                Combine(pf, @"BraveSoftware\Brave-Browser\Application\brave.exe"),
                Combine(pf86, @"BraveSoftware\Brave-Browser\Application\brave.exe"),
                Combine(local, @"BraveSoftware\Brave-Browser\Application\brave.exe")
            };
            browsers.Add(brave);

            BrowserInfo vivaldi = new BrowserInfo();
            vivaldi.Name = "Vivaldi";
            vivaldi.VendorKey = @"Software\Vivaldi";
            vivaldi.ExtPage = "vivaldi://extensions/";
            vivaldi.UserDataDir = Path.Combine(local, @"Vivaldi\User Data");
            vivaldi.ExePaths = new string[] {
                Combine(pf, @"Vivaldi\Application\vivaldi.exe"),
                Combine(pf86, @"Vivaldi\Application\vivaldi.exe"),
                Combine(local, @"Vivaldi\Application\vivaldi.exe")
            };
            browsers.Add(vivaldi);

            BrowserInfo chromium = new BrowserInfo();
            chromium.Name = "Chromium";
            chromium.VendorKey = @"Software\Chromium";
            chromium.ExtPage = "chrome://extensions/";
            chromium.UserDataDir = Path.Combine(local, @"Chromium\User Data");
            chromium.ExePaths = new string[] {
                Combine(local, @"Chromium\Application\chrome.exe"),
                Combine(pf, @"Chromium\Application\chrome.exe")
            };
            browsers.Add(chromium);

            foreach (BrowserInfo b in browsers)
            {
                foreach (string p in b.ExePaths)
                {
                    try { if (p != null && File.Exists(p)) { b.ExePath = p; break; } }
                    catch { }
                }
                if (b.ExePath == null) { string r = FindInRegistry(b); if (r != null) b.ExePath = r; }
            }
        }

        static string Combine(string root, string tail)
        {
            if (String.IsNullOrEmpty(root)) return null;
            return Path.Combine(root, tail);
        }

        static string FindInRegistry(BrowserInfo b)
        {
            string want = Path.GetFileName(b.ExePaths[0]);
            string[] roots = new string[] {
                @"SOFTWARE\Clients\StartMenuInternet",
                @"SOFTWARE\WOW6432Node\Clients\StartMenuInternet"
            };
            foreach (string root in roots)
            {
                string sub = null;
                try
                {
                    using (RegistryKey baseKey = Registry.LocalMachine.OpenSubKey(root))
                    {
                        if (baseKey == null) continue;
                        foreach (string n in baseKey.GetSubKeyNames())
                        {
                            if (String.Equals(n, want, StringComparison.OrdinalIgnoreCase)) { sub = n; break; }
                        }
                    }
                }
                catch { continue; }
                if (sub == null) continue;
                try
                {
                    using (RegistryKey cmdKey = Registry.LocalMachine.OpenSubKey(root + @"\" + sub + @"\shell\open\command"))
                    {
                        if (cmdKey == null) continue;
                        string cmd = cmdKey.GetValue(null) as string;
                        if (String.IsNullOrEmpty(cmd)) continue;
                        string exe = cmd.Trim();
                        if (exe.StartsWith("\"")) { int e = exe.IndexOf('"', 1); if (e > 1) exe = exe.Substring(1, e - 1); }
                        else { int sp = exe.IndexOf(' '); if (sp > 0) exe = exe.Substring(0, sp); }
                        if (File.Exists(exe)) return exe;
                    }
                }
                catch { }
            }
            return null;
        }

        /* ---------------- установка ---------------- */

        List<BrowserInfo> CollectChosen()
        {
            List<BrowserInfo> chosen = new List<BrowserInfo>();
            foreach (CheckBox cb in boxes)
            {
                BrowserInfo b = cb.Tag as BrowserInfo;
                if (cb.Checked && b != null) { b.Selected = true; chosen.Add(b); }
            }
            return chosen;
        }

        void OnInstall(object sender, EventArgs e)
        {
            List<BrowserInfo> chosen = CollectChosen();
            if (chosen.Count == 0)
            {
                MessageBox.Show(this, "Отметьте хотя бы один браузер в списке.", "Undo Bridge",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            if (!InstallCore(chosen)) return;

            installed.Clear();
            installed.AddRange(chosen);
            ShowSteps(chosen);

            if (optOpenPage.Checked)
            {
                foreach (BrowserInfo b in chosen) OpenExtPage(b);
            }
        }

        bool InstallCore(List<BrowserInfo> chosen)
        {
            try
            {
                Say("Папка дополнения: " + extDir);
                ExtractExtension();
                ExtractAgent();
                StartAgent();

                extId = BuildCrx();
                Say("ID дополнения: " + extId + "   версия " + ExtVersion());

                foreach (BrowserInfo b in chosen)
                {
                    try
                    {
                        RegisterExternal(b, extId);
                        Say(b.Name + ": запись в реестре добавлена");
                    }
                    catch (Exception ex) { Say(b.Name + ": реестр — " + ex.Message); }

                    if (optShortcut.Checked)
                    {
                        try { CreateShortcut(b); }
                        catch (Exception ex) { Say(b.Name + ": ярлык — " + ex.Message); }
                    }
                }

                if (optAutostart.Checked) SetAutostart();

                if (optClipboard.Checked)
                {
                    try
                    {
                        Clipboard.SetText(extDir);
                        Say("Путь к дополнению скопирован в буфер обмена");
                    }
                    catch (Exception ex) { Say("буфер обмена: " + ex.Message); }
                }

                Say("Файлы готовы. Дальше — три клика в браузере (см. ниже).");
                return true;
            }
            catch (Exception ex)
            {
                Say("ОШИБКА: " + ex.Message);
                if (!silent)
                {
                    MessageBox.Show(this, "Установка прервана:\n\n" + ex.Message, "Undo Bridge",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                return false;
            }
        }

        void ShowSteps(List<BrowserInfo> chosen)
        {
            StringBuilder names = new StringBuilder();
            foreach (BrowserInfo b in chosen)
            {
                if (names.Length > 0) names.Append(", ");
                names.Append(b.Name);
            }
            stepsTitle.Text = "Готово. Движок в фоне, осталось 3 клика: " + names;
            stepsText.Text =
                "1. На открывшейся странице дополнений включите «Режим разработчика».\r\n" +
                "2. Нажмите «Загрузить распакованное расширение».\r\n" +
                "3. Вставьте путь (Ctrl+V) и нажмите Enter.\r\n" +
                "Путь: " + extDir + "\r\n" +
                (File.Exists(agentExe) ? "Движок Undo уже работает в фоне — окна у него нет." : "");
            stepsPanel.Visible = true;
        }

        void OpenExtPage(BrowserInfo b)
        {
            try
            {
                Process.Start(b.ExePath, b.ExtPage);
                Say(b.Name + ": открыта страница дополнений");
            }
            catch (Exception ex) { Say(b.Name + ": " + ex.Message); }
        }

        void OnOpenPage(object sender, EventArgs e)
        {
            List<BrowserInfo> list = installed.Count > 0 ? installed : CollectChosen();
            if (list.Count == 0) { Say("не выбран ни один браузер"); return; }
            foreach (BrowserInfo b in list) OpenExtPage(b);
        }

        void OnCopyPath(object sender, EventArgs e)
        {
            try
            {
                if (!Directory.Exists(extDir)) { Say("сначала нажмите «Установить» — папки ещё нет"); return; }
                Clipboard.SetText(extDir);
                Say("путь скопирован в буфер: " + extDir);
            }
            catch (Exception ex) { Say("буфер обмена: " + ex.Message); }
        }

        void OnCheck(object sender, EventArgs e)
        {
            List<BrowserInfo> list = installed.Count > 0 ? installed : CollectChosen();
            if (list.Count == 0) { Say("нечего проверять — выберите браузер"); return; }

            int ok = 0;
            foreach (BrowserInfo b in list)
            {
                string state = ExtensionState(b, extId);
                if (state.StartsWith("загружено")) ok++;
                Say(b.Name + ": " + state);
            }

            if (ok == list.Count)
            {
                Say("Всё на месте. Откройте чат DeepSeek и обновите вкладку (F5).");
                stepsTitle.Text = "Дополнение установлено и загружено";
                stepsText.Text =
                    "Панель «Undo Bridge» появится внизу справа на вкладке chat.deepseek.com.\r\n" +
                    "Не забудьте запустить Undo — он читает буфер каждые 700 мс.\r\n" +
                    "Разрешения дополнения уже выданы при загрузке.";
            }
            else
            {
                Say("Если написано «не найдено» — выполните 3 шага выше (это разово) и нажмите «Проверить» снова.");
            }
        }

        /* ---------------- файлы и система ---------------- */

        void ExtractExtension()
        {
            Directory.CreateDirectory(targetDir);
            if (Directory.Exists(extDir))
            {
                try { Directory.Delete(extDir, true); } catch { }
            }
            Directory.CreateDirectory(extDir);

            Assembly asm = Assembly.GetExecutingAssembly();
            Stream src = asm.GetManifestResourceStream("UndoBridge.ext.zip");
            if (src == null) throw new Exception("в установщик не вложены файлы дополнения");

            string tmp = Path.Combine(targetDir, "ext-package.zip");
            using (FileStream fs = new FileStream(tmp, FileMode.Create, FileAccess.Write))
            {
                byte[] buf = new byte[81920];
                int n;
                while ((n = src.Read(buf, 0, buf.Length)) > 0) fs.Write(buf, 0, n);
            }
            src.Close();

            ZipFile.ExtractToDirectory(tmp, extDir);
            try { File.Delete(tmp); } catch { }

            int count = 0;
            try { count = Directory.GetFiles(extDir, "*", SearchOption.AllDirectories).Length; } catch { }
            Say("Файлы дополнения распакованы (" + count + " шт.)");
        }

        /* Движок Undo — самодостаточный exe (собран PyInstaller), Python не нужен. */
        void ExtractAgent()
        {
            Assembly asm = Assembly.GetExecutingAssembly();
            Stream src = asm.GetManifestResourceStream("UndoBridge.agent.exe");
            if (src == null)
            {
                Say("движок Undo не вложен в установщик — ставим только дополнение");
                return;
            }
            Directory.CreateDirectory(agentDir);
            string tmp = agentExe + ".new";
            using (FileStream fs = new FileStream(tmp, FileMode.Create, FileAccess.Write))
            {
                byte[] buf = new byte[81920];
                int n;
                while ((n = src.Read(buf, 0, buf.Length)) > 0) fs.Write(buf, 0, n);
            }
            src.Close();
            try
            {
                if (File.Exists(agentExe)) File.Delete(agentExe);
            }
            catch { }
            try { File.Move(tmp, agentExe); }
            catch { try { File.Copy(tmp, agentExe, true); File.Delete(tmp); } catch { } }
            Say("Движок Undo установлен: " + agentExe);
        }

        /* Запуск движка без окна: интерфейс живёт в дополнении. */
        void StartAgent()
        {
            if (!File.Exists(agentExe)) return;
            Process[] running = Process.GetProcessesByName("UndoBridgeAgent");
            if (running != null && running.Length > 0)
            {
                Say("Движок уже запущен");
                return;
            }
            try
            {
                ProcessStartInfo psi = new ProcessStartInfo();
                psi.FileName = agentExe;
                psi.Arguments = "--headless";
                psi.WorkingDirectory = agentDir;
                psi.UseShellExecute = false;
                psi.CreateNoWindow = true;
                Process.Start(psi);
                Say("Движок запущен в фоне (окна нет)");
            }
            catch (Exception ex) { Say("запуск движка: " + ex.Message); }
        }

        string ExtVersion()
        {
            try
            {
                string json = File.ReadAllText(Path.Combine(extDir, "manifest.json"), Encoding.UTF8);
                System.Text.RegularExpressions.Match m =
                    System.Text.RegularExpressions.Regex.Match(json, "\"version\"\\s*:\\s*\"([^\"]+)\"");
                if (m.Success) return m.Groups[1].Value;
            }
            catch { }
            return "1.0.0";
        }

        void RegisterExternal(BrowserInfo b, string id)
        {
            string key = b.VendorKey + @"\Extensions\" + id;
            using (RegistryKey rk = Registry.CurrentUser.CreateSubKey(key))
            {
                if (rk == null) throw new Exception("не удалось создать ключ " + key);
                rk.SetValue("path", crxPath, RegistryValueKind.String);
                rk.SetValue("version", ExtVersion(), RegistryValueKind.String);
            }
        }

        void CreateShortcut(BrowserInfo b)
        {
            string desktop = Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory);
            string lnk = Path.Combine(desktop, "DeepSeek + Undo (" + b.Name + ").lnk");
            object shell = null;
            try
            {
                Type t = Type.GetTypeFromProgID("WScript.Shell");
                if (t == null) throw new Exception("WScript.Shell недоступен");
                shell = Activator.CreateInstance(t);
                object sc = t.InvokeMember("CreateShortcut", BindingFlags.InvokeMethod, null, shell, new object[] { lnk });
                Type sct = sc.GetType();
                sct.InvokeMember("TargetPath", BindingFlags.SetProperty, null, sc, new object[] { b.ExePath });
                sct.InvokeMember("Arguments", BindingFlags.SetProperty, null, sc, new object[] { "https://chat.deepseek.com/" });
                sct.InvokeMember("WorkingDirectory", BindingFlags.SetProperty, null, sc, new object[] { Path.GetDirectoryName(b.ExePath) });
                sct.InvokeMember("Description", BindingFlags.SetProperty, null, sc, new object[] { "DeepSeek + Undo Bridge" });
                sct.InvokeMember("Save", BindingFlags.InvokeMethod, null, sc, null);
                Say(b.Name + ": ярлык «DeepSeek + Undo» на рабочем столе");
            }
            finally
            {
                if (shell != null) System.Runtime.InteropServices.Marshal.ReleaseComObject(shell);
            }
        }

        void SetAutostart()
        {
            string cmd;
            if (File.Exists(agentExe))
            {
                // наш собственный движок: стартует без окна вместе с Windows
                cmd = "\"" + agentExe + "\" --headless";
            }
            else
            {
                string undo = FindUndo();
                if (undo == null)
                {
                    Say("Undo не найден — автозапуск пропущен (запустите его вручную)");
                    return;
                }
                cmd = undo;
            }
            using (RegistryKey rk = Registry.CurrentUser.CreateSubKey(
                @"Software\Microsoft\Windows\CurrentVersion\Run"))
            {
                if (rk == null) { Say("автозапуск: нет доступа к реестру"); return; }
                rk.SetValue("UndoBridgeAgent", cmd, RegistryValueKind.String);
            }
            Say("Автозапуск: " + cmd);
        }

        string FindUndo()
        {
            string local = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
            string[] candidates = new string[] {
                Path.Combine(local, @"Programs\Undo\Undo.exe"),
                Path.Combine(local, @"Undo\Undo.exe"),
                Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles), @"Undo\Undo.exe"),
                Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86), @"Undo\Undo.exe")
            };
            foreach (string c in candidates) { try { if (File.Exists(c)) return "\"" + c + "\""; } catch { } }

            string desktop = Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory);
            string[] scripts = new string[] {
                Path.Combine(desktop, @"undo\repo\Undo.py"),
                Path.Combine(desktop, @"undo\Undo.py")
            };
            foreach (string s in scripts)
            {
                try
                {
                    if (!File.Exists(s)) continue;
                    foreach (string pyw in Directory.GetFiles(
                        Path.Combine(local, @"Programs\Python"), "pythonw.exe", SearchOption.AllDirectories))
                    {
                        return "\"" + pyw + "\" \"" + s + "\"";
                    }
                }
                catch { }
            }
            return null;
        }

        /* ---------------- тихий режим ---------------- */

        public static int RunSilent(string want, bool shortcut)
        {
            SetupForm f = new SetupForm();
            f.silent = true;

            List<BrowserInfo> chosen = new List<BrowserInfo>();
            foreach (BrowserInfo b in f.browsers)
            {
                if (!b.Found) continue;
                if (!String.IsNullOrEmpty(want) && !Matches(b, want)) continue;
                chosen.Add(b);
            }

            f.optOpenPage.Checked = false;
            f.optClipboard.Checked = false;
            f.optAutostart.Checked = false;
            f.optShortcut.Checked = shortcut;

            bool ok = false;
            if (chosen.Count == 0) f.Say("подходящих браузеров не найдено");
            else ok = f.InstallCore(chosen);

            try
            {
                Directory.CreateDirectory(f.targetDir);
                File.WriteAllText(Path.Combine(f.targetDir, "install.log"), f.log.Text, Encoding.UTF8);
            }
            catch { }
            return ok ? 0 : 1;
        }

        static bool Matches(BrowserInfo b, string want)
        {
            string w = want.ToLower();
            string id = "edge";
            if (b.VendorKey.IndexOf("Chrome", StringComparison.OrdinalIgnoreCase) >= 0) id = "chrome";
            else if (b.VendorKey.IndexOf("Yandex", StringComparison.OrdinalIgnoreCase) >= 0) id = "yandex";
            return w.IndexOf(id) >= 0 || w.IndexOf(b.Name.ToLower()) >= 0;
        }

        /* ---------------- проверка: загружено ли дополнение ---------------- */

        static string[] ProfilesOf(string userDataDir)
        {
            List<string> dirs = new List<string>();
            if (String.IsNullOrEmpty(userDataDir)) return dirs.ToArray();
            try
            {
                if (!Directory.Exists(userDataDir)) return dirs.ToArray();
                foreach (string d in Directory.GetDirectories(userDataDir))
                {
                    string name = Path.GetFileName(d);
                    if (String.Equals(name, "Default", StringComparison.OrdinalIgnoreCase)
                        || name.StartsWith("Profile", StringComparison.OrdinalIgnoreCase))
                        dirs.Add(d);
                }
            }
            catch { }
            return dirs.ToArray();
        }

        /* Ищем следы дополнения в профиле: путь к папке или id из CRX.
           Так видно и распакованное (загружено вручную), и внешнее из реестра. */
        static string ExtensionState(BrowserInfo b, string extId)
        {
            string[] profiles = ProfilesOf(b.UserDataDir);
            if (profiles.Length == 0) return "профиль браузера не найден";
            foreach (string dir in profiles)
            {
                foreach (string f in new string[] { "Preferences", "Secure Preferences" })
                {
                    try
                    {
                        string p = Path.Combine(dir, f);
                        if (!File.Exists(p)) continue;
                        string text = File.ReadAllText(p);
                        if (text.IndexOf("UndoBridge", StringComparison.OrdinalIgnoreCase) >= 0)
                            return "загружено (" + Path.GetFileName(dir) + ")";
                        if (!String.IsNullOrEmpty(extId)
                            && text.IndexOf(extId, StringComparison.OrdinalIgnoreCase) >= 0)
                            return "загружено (" + Path.GetFileName(dir) + ")";
                    }
                    catch { }
                }
            }
            return "не найдено";
        }

        /* ---------------- CRX3: упаковка и подпись ---------------- */

        string BuildCrx()
        {
            string zip = Path.Combine(targetDir, "ext-package.zip");
            try { if (File.Exists(zip)) File.Delete(zip); } catch { }
            ZipFile.CreateFromDirectory(extDir, zip, CompressionLevel.Optimal, false);
            byte[] zipBytes = File.ReadAllBytes(zip);
            try { File.Delete(zip); } catch { }

            RSACryptoServiceProvider rsa = LoadOrCreateKey();
            byte[] pub = SubjectPublicKeyInfo(rsa);
            byte[] idBytes = ExtIdBytes(pub);
            string id = HexToId(idBytes);

            byte[] signedHeader = Field(1, idBytes);

            MemoryStream ms = new MemoryStream();
            byte[] magic = Encoding.ASCII.GetBytes("CRX3 SignedData");
            ms.Write(magic, 0, magic.Length);
            ms.WriteByte(0);
            byte[] hdrLen = LE32(signedHeader.Length);
            ms.Write(hdrLen, 0, hdrLen.Length);
            ms.Write(signedHeader, 0, signedHeader.Length);
            ms.Write(zipBytes, 0, zipBytes.Length);
            byte[] toSign = ms.ToArray();

            byte[] sig = rsa.SignData(toSign, "SHA256");

            byte[] proof = Concat(new byte[][] { Field(1, pub), Field(2, sig) });
            byte[] header = Concat(new byte[][] { Field(2, proof), Field(10000, signedHeader) });

            MemoryStream outMs = new MemoryStream();
            byte[] crxMagic = Encoding.ASCII.GetBytes("Cr24");
            outMs.Write(crxMagic, 0, 4);
            byte[] ver = LE32(3);
            outMs.Write(ver, 0, 4);
            byte[] hlen = LE32(header.Length);
            outMs.Write(hlen, 0, hlen.Length);
            outMs.Write(header, 0, header.Length);
            outMs.Write(zipBytes, 0, zipBytes.Length);

            File.WriteAllBytes(crxPath, outMs.ToArray());
            try { File.WriteAllText(Path.Combine(targetDir, "extension-id.txt"), id, Encoding.ASCII); } catch { }
            Say("Дополнение упаковано: " + crxPath);
            return id;
        }

        RSACryptoServiceProvider LoadOrCreateKey()
        {
            RSACryptoServiceProvider rsa = new RSACryptoServiceProvider(2048);
            rsa.PersistKeyInCsp = false;
            try
            {
                if (File.Exists(keyPath))
                {
                    rsa.FromXmlString(File.ReadAllText(keyPath, Encoding.UTF8));
                    return rsa;
                }
            }
            catch { }
            try { File.WriteAllText(keyPath, rsa.ToXmlString(true), Encoding.UTF8); } catch { }
            return rsa;
        }

        static byte[] SubjectPublicKeyInfo(RSACryptoServiceProvider rsa)
        {
            RSAParameters p = rsa.ExportParameters(false);
            byte[] algId = Der(0x30, Concat(new byte[][] {
                Der(0x06, new byte[] { 0x2A, 0x86, 0x48, 0x86, 0xF7, 0x0D, 0x01, 0x01, 0x01 }),
                Der(0x05, new byte[0])
            }));
            byte[] rsaPub = Der(0x30, Concat(new byte[][] {
                DerInteger(p.Modulus),
                DerInteger(p.Exponent)
            }));
            byte[] bitString = Der(0x03, Concat(new byte[][] { new byte[] { 0x00 }, rsaPub }));
            return Der(0x30, Concat(new byte[][] { algId, bitString }));
        }

        static byte[] ExtIdBytes(byte[] spki)
        {
            using (SHA256 sha = SHA256.Create())
            {
                byte[] hash = sha.ComputeHash(spki);
                byte[] id = new byte[16];
                Array.Copy(hash, id, 16);
                return id;
            }
        }

        static string HexToId(byte[] id)
        {
            StringBuilder sb = new StringBuilder();
            foreach (byte b in id)
            {
                sb.Append((char)('a' + (b >> 4)));
                sb.Append((char)('a' + (b & 0x0F)));
            }
            return sb.ToString();
        }

        static byte[] LE32(int v)
        {
            return new byte[] { (byte)(v & 0xFF), (byte)((v >> 8) & 0xFF), (byte)((v >> 16) & 0xFF), (byte)((v >> 24) & 0xFF) };
        }

        static byte[] Varint(int value)
        {
            List<byte> b = new List<byte>();
            uint v = (uint)value;
            while (v >= 0x80) { b.Add((byte)((v & 0x7F) | 0x80)); v >>= 7; }
            b.Add((byte)v);
            return b.ToArray();
        }

        static byte[] Field(int number, byte[] payload)
        {
            return Concat(new byte[][] { Varint((number << 3) | 2), Varint(payload.Length), payload });
        }

        static byte[] Concat(byte[][] parts)
        {
            int total = 0;
            for (int i = 0; i < parts.Length; i++) total += parts[i].Length;
            byte[] outBuf = new byte[total];
            int pos = 0;
            for (int i = 0; i < parts.Length; i++)
            {
                Array.Copy(parts[i], 0, outBuf, pos, parts[i].Length);
                pos += parts[i].Length;
            }
            return outBuf;
        }

        static byte[] DerLen(int len)
        {
            if (len < 0x80) return new byte[] { (byte)len };
            if (len < 0x100) return new byte[] { 0x81, (byte)len };
            if (len < 0x10000) return new byte[] { 0x82, (byte)(len >> 8), (byte)(len & 0xFF) };
            return new byte[] { 0x83, (byte)(len >> 16), (byte)((len >> 8) & 0xFF), (byte)(len & 0xFF) };
        }

        static byte[] Der(byte tag, byte[] content)
        {
            return Concat(new byte[][] { new byte[] { tag }, DerLen(content.Length), content });
        }

        static byte[] DerInteger(byte[] bigEndian)
        {
            int i = 0;
            while (i < bigEndian.Length - 1 && bigEndian[i] == 0) i++;
            List<byte> body = new List<byte>();
            for (int k = i; k < bigEndian.Length; k++) body.Add(bigEndian[k]);
            if ((body[0] & 0x80) != 0) body.Insert(0, 0);
            return Der(0x02, body.ToArray());
        }
    }

    static class Program
    {
        [STAThread]
        static void Main(string[] args)
        {
            try
            {
                Application.EnableVisualStyles();
                Application.SetCompatibleTextRenderingDefault(false);

                bool silent = false;
                bool shortcut = false;
                string want = null;
                if (args != null)
                {
                    foreach (string a in args)
                    {
                        if (String.Equals(a, "--silent", StringComparison.OrdinalIgnoreCase)) silent = true;
                        else if (String.Equals(a, "--shortcut", StringComparison.OrdinalIgnoreCase)) shortcut = true;
                        else if (a.StartsWith("--browsers=", StringComparison.OrdinalIgnoreCase))
                            want = a.Substring("--browsers=".Length);
                    }
                }

                if (silent) { Environment.Exit(SetupForm.RunSilent(want, shortcut)); return; }

                Application.Run(new SetupForm());
            }
            catch (Exception e)
            {
                MessageBox.Show(e.ToString(), "Undo Bridge — ошибка");
            }
        }
    }
}
