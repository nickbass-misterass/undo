// Undo Bridge — установщик дополнения для Яндекс.Браузера / Chrome / Edge.
// Компилируется csc.exe из .NET Framework 4.x, без внешних зависимостей.
//
// Что делает установщик:
//   1. распаковывает дополнение в %LOCALAPPDATA%\UndoBridge\extension;
//   2. собирает подписанный CRX3 и прописывает его в реестр браузера (best effort);
//   3. открывает страницу дополнений и кладёт путь в буфер обмена;
//   4. показывает пошаговую инструкцию и умеет проверить результат.

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.IO.Compression;
using System.Reflection;
using System.Security.Cryptography;
using System.Text;
using System.Windows.Forms;
using Microsoft.Win32;

namespace UndoBridgeSetup
{
    /* Локализация: английский по умолчанию, переключатель в правом верхнем углу.
       Ключ -> [en, ru, zh]. */
    static class L
    {
        public static string Lang = "en";

        static readonly Dictionary<string, string[]> T = new Dictionary<string, string[]>();

        static void Add(string k, string en, string ru, string zh) { T[k] = new string[] { en, ru, zh }; }

        static L()
        {
            Add("win.title", "Undo Bridge - extension setup", "Undo Bridge - установка дополнения", "Undo Bridge - 安装扩展");
            Add("sub", "Undo runs as a background engine without a window; the whole interface lives\nin the browser extension: an in-page panel and a full side panel.",
                "Undo ставится как фоновый движок без окна, а весь интерфейс -\nв дополнении браузера: панель на странице и полное окно в боковой панели.",
                "Undo 作为无窗口的后台引擎运行; 全部界面都在\n浏览器扩展中: 页面面板和完整的侧边栏。");

            Add("gb.browser", " 1. Where to install (multiple allowed) ", " 1. Куда установить (можно несколько) ", " 1. 安装位置 (可多选) ");
            Add("gb.options", " 2. Options ", " 2. Параметры ", " 2. 选项 ");
            Add("browser.missing", "  - not found", "  - нет", "  - 未安装");

            Add("opt.open", "Open the extensions page after installation", "Открыть страницу дополнений сразу после установки", "安装后打开扩展管理页面");
            Add("opt.clipboard", "Copy the extension folder path to the clipboard", "Скопировать путь к папке дополнения в буфер обмена", "将扩展文件夹路径复制到剪贴板");
            Add("opt.shortcut", "Create a desktop shortcut \"DeepSeek + Undo\"", "Создать на рабочем столе ярлык «DeepSeek + Undo»", "在桌面创建 \"DeepSeek + Undo\" 快捷方式");
            Add("opt.autostart", "Run Undo in the background at Windows startup", "Запускать Undo в фоне при входе в Windows", "Windows 启动时在后台运行 Undo");

            Add("btn.install", "INSTALL", "УСТАНОВИТЬ", "安 装");
            Add("btn.check", "Check", "Проверить", "检查");
            Add("btn.close", "Close", "Закрыть", "关闭");
            Add("btn.step.open", "Open extensions", "Открыть дополнения", "打开扩展页面");
            Add("btn.step.copy", "Copy path", "Скопировать путь", "复制路径");
            Add("btn.step.check", "Check install", "Проверить установку", "检查安装");

            Add("log.found", "Browsers found: {0}. Choose them and press Install.", "Найдено браузеров: {0}. Выберите и нажмите «Установить».", "找到浏览器: {0} 个。请选择并点击\"安装\"。");
            Add("msg.nobrowser", "Select at least one browser in the list.", "Отметьте хотя бы один браузер в списке.", "请在列表中选择至少一个浏览器。");

            Add("say.extdir", "Extension folder: {0}", "Папка дополнения: {0}", "扩展文件夹: {0}");
            Add("say.files", "Extension files extracted ({0} files)", "Файлы дополнения распакованы ({0} шт.)", "扩展文件已解压 ({0} 个文件)");
            Add("say.packed", "Extension packed: {0}", "Дополнение упаковано: {0}", "扩展已打包: {0}");
            Add("say.id", "Extension ID: {0}   version {1}", "ID дополнения: {0}   версия {1}", "扩展 ID: {0}   版本 {1}");
            Add("say.registry", "{0}: registry entry added", "{0}: запись в реестре добавлена", "{0}: 已写入注册表");
            Add("say.registry.err", "{0}: registry - {1}", "{0}: реестр - {1}", "{0}: 注册表 - {1}");
            Add("say.shortcut.ok", "{0}: \"DeepSeek + Undo\" shortcut on the desktop", "{0}: ярлык «DeepSeek + Undo» на рабочем столе", "{0}: 桌面已创建 \"DeepSeek + Undo\" 快捷方式");
            Add("say.shortcut.err", "{0}: shortcut - {1}", "{0}: ярлык - {1}", "{0}: 快捷方式 - {1}");
            Add("say.clip", "Extension path copied to the clipboard", "Путь к дополнению скопирован в буфер обмена", "扩展路径已复制到剪贴板");
            Add("say.clip.err", "clipboard: {0}", "буфер обмена: {0}", "剪贴板: {0}");
            Add("say.ready", "Files are ready. Next - three clicks in the browser (see below).", "Файлы готовы. Дальше - три клика в браузере (см. ниже).", "文件已就绪。接下来在浏览器中点击三次 (见下方)。");
            Add("say.error", "ERROR: {0}", "ОШИБКА: {0}", "错误: {0}");
            Add("msg.fail.title", "Installation interrupted:", "Установка прервана:", "安装已中断:");
            Add("msg.error.title", "Undo Bridge - error", "Undo Bridge - ошибка", "Undo Bridge - 错误");
            Add("msg.hint", "The browser page is open.\n\n1. Turn on the \"Developer mode\" switch in the TOP RIGHT corner - the page changes and a new button appears.\n2. Press \"Load unpacked\".\n3. Paste the path with Ctrl+V and press Enter.\n\nThe path is already in the clipboard:\n{0}",
                "Страница дополнений открыта.\n\n1. Включите тумблер «Режим разработчика» в ПРАВОМ ВЕРХНЕМ углу — страница изменится и появится новая кнопка.\n2. Нажмите «Загрузить распакованное расширение».\n3. Вставьте путь (Ctrl+V) и нажмите Enter.\n\nПуть уже в буфере обмена:\n{0}",
                "扩展页面已打开。\n\n1. 打开右上角的\"开发者模式\"开关 — 页面会变化并出现新按钮。\n2. 点击\"加载已解压的扩展程序\"。\n3. 按 Ctrl+V 粘贴路径并按回车。\n\n路径已在剪贴板中：\n{0}");
            Add("btn.open.page", "OPEN EXTENSIONS PAGE", "ОТКРЫТЬ СТРАНИЦУ ДОПОЛНЕНИЙ", "打开扩展页面");

            Add("say.agent.missing", "Undo engine is not embedded - installing the extension only", "движок Undo не вложен в установщик - ставим только дополнение", "未内置 Undo 引擎 - 仅安装扩展");
            Add("say.agent.ok", "Undo engine installed: {0}", "Движок Undo установлен: {0}", "Undo 引擎已安装: {0}");
            Add("say.agent.busy", "engine is busy: the new version is saved as UndoBridgeAgent.exe.new - close Undo and run setup again",
                "движок занят: новая версия сохранена как UndoBridgeAgent.exe.new - закройте Undo и запустите установку снова",
                "引擎被占用: 新版本已保存为 UndoBridgeAgent.exe.new - 请关闭 Undo 后重新运行安装程序");
            Add("say.agent.running", "Engine is already running", "Движок уже запущен", "引擎已在运行");
            Add("say.agent.started", "Engine started in background (no window)", "Движок запущен в фоне (окна нет)", "引擎已在后台启动 (无窗口)");
            Add("say.agent.err", "engine start: {0}", "запуск движка: {0}", "启动引擎: {0}");

            Add("say.page.opened", "{0}: extensions page opened", "{0}: открыта страница дополнений", "{0}: 已打开扩展页面");
            Add("say.page.err", "{0}: {1}", "{0}: {1}", "{0}: {1}");
            Add("say.nobrowser.selected", "no browser selected", "не выбран ни один браузер", "未选择浏览器");
            Add("say.need.install", "press Install first - the folder does not exist yet", "сначала нажмите «Установить» - папки ещё нет", "请先点击\"安装\" - 文件夹尚不存在");
            Add("say.copied", "path copied to clipboard: {0}", "путь скопирован в буфер: {0}", "路径已复制到剪贴板: {0}");
            Add("say.nothing.check", "nothing to check - choose a browser", "нечего проверять - выберите браузер", "没有可检查的内容 - 请选择浏览器");
            Add("say.allok", "Everything is in place. Open the DeepSeek chat and reload the tab (F5).", "Всё на месте. Откройте чат DeepSeek и обновите вкладку (F5).", "一切就绪。打开 DeepSeek 聊天并刷新标签页 (F5)。");
            Add("say.ifnone", "If it says \"not found\" - do the 3 steps above (one time) and press Check again.",
                "Если написано «не найдено» - выполните 3 шага выше (это разово) и нажмите «Проверить» снова.",
                "如果显示\"未找到\" - 请执行上面的 3 个步骤 (只需一次) 然后再次点击\"检查\"。");
            Add("say.autostart", "Autostart: {0}", "Автозапуск: {0}", "开机自启: {0}");
            Add("say.autostart.skip", "Undo not found - autostart skipped (run it manually)", "Undo не найден - автозапуск пропущен (запустите его вручную)", "未找到 Undo - 已跳过开机自启 (请手动运行)");
            Add("say.autostart.noreg", "autostart: no registry access", "автозапуск: нет доступа к реестру", "开机自启: 无法访问注册表");
            Add("say.silent.none", "no suitable browsers found", "подходящих браузеров не найдено", "未找到合适的浏览器");

            Add("step.done", "Done. Engine runs in background - 3 clicks left: {0}", "Готово. Движок в фоне, осталось 3 клика: {0}", "完成。引擎在后台运行 - 还剩 3 次点击: {0}");
            Add("step.text", "1. On the open extensions page turn on \"Developer mode\" - the switch is in the TOP RIGHT corner.\r\n2. Press \"Load unpacked\".\r\n3. Paste the path (Ctrl+V) and press Enter.\r\nPath: {0}\r\n{1}",
                "1. На открывшейся странице дополнений включите «Режим разработчика» — тумблер в ПРАВОМ ВЕРХНЕМ углу.\r\n2. Нажмите «Загрузить распакованное расширение».\r\n3. Вставьте путь (Ctrl+V) и нажмите Enter.\r\nПуть: {0}\r\n{1}",
                "1. 在打开的扩展页面中启用\"开发者模式\" — 开关在右上角。\r\n2. 点击\"加载已解压的扩展程序\"。\r\n3. 粘贴路径 (Ctrl+V) 并按回车。\r\n路径: {0}\r\n{1}");
            Add("step.agent.note", "The Undo engine is already running in background - it has no window.", "Движок Undo уже работает в фоне - окна у него нет.", "Undo 引擎已在后台运行 - 它没有窗口。");
            Add("step.ok.title", "Extension installed and loaded", "Дополнение установлено и загружено", "扩展已安装并加载");
            Add("step.ok.text", "The \"Undo Bridge\" panel appears at the bottom right on chat.deepseek.com.\r\nThe engine reads the clipboard every 700 ms - keep it running.\r\nExtension permissions were granted when you loaded it.",
                "Панель «Undo Bridge» появится внизу справа на вкладке chat.deepseek.com.\r\nНе забудьте запустить Undo - он читает буфер каждые 700 мс.\r\nРазрешения дополнения уже выданы при загрузке.",
                "\"Undo Bridge\" 面板会出现在 chat.deepseek.com 的右下角。\r\n引擎每 700 毫秒读取剪贴板 - 请保持运行。\r\n扩展权限已在加载时授予。");

            Add("state.loaded", "loaded ({0})", "загружено ({0})", "已加载 ({0})");
            Add("state.missing", "not found", "не найдено", "未找到");
            Add("state.noprofile", "browser profile not found", "профиль браузера не найден", "未找到浏览器配置文件");
            Add("browser.yandex", "Yandex Browser", "Яндекс.Браузер", "Yandex 浏览器");

            /* --- короткий путь: копировать путь + анимированная инструкция --- */
            Add("btn.copy.quick", "COPY PATH", "КОПИРОВАТЬ ПУТЬ", "复制路径");
            Add("say.prepared", "Extension files are ready: {0}", "Файлы дополнения готовы: {0}", "扩展文件已就绪: {0}");
            Add("say.copied.ok", "Path copied. Paste it in the browser with Ctrl+V.", "Путь скопирован. Вставьте его в браузере через Ctrl+V.", "路径已复制。在浏览器中按 Ctrl+V 粘贴。");

            Add("guide.title", "How to load it in the browser - 3 steps", "Как загрузить в браузер - 3 шага", "如何在浏览器中加载 - 3 个步骤");
            Add("guide.1", "Open the address bar and type browser://extensions/ then press Enter.",
                "Откройте адресную строку, введите browser://extensions/ и нажмите Enter.",
                "打开地址栏, 输入 browser://extensions/ 然后按回车。");
            Add("guide.2", "Turn on \"Developer mode\" (top right), then press \"Load unpacked\".",
                "Включите «Режим разработчика» (справа сверху), затем нажмите «Загрузить распакованное расширение».",
                "打开右上角的\"开发者模式\", 然后点击\"加载已解压的扩展程序\"。");
            Add("guide.3", "Paste the copied path with Ctrl+V and confirm - the extension appears in the list.",
                "Вставьте скопированный путь через Ctrl+V и подтвердите - дополнение появится в списке.",
                "按 Ctrl+V 粘贴复制的路径并确认 - 扩展会出现在列表中。");
            Add("guide.bar", "browser://extensions/", "browser://extensions/", "browser://extensions/");
            Add("guide.dev", "Developer mode", "Режим разработчика", "开发者模式");
            Add("guide.load", "Load unpacked", "Загрузить распакованное", "加载已解压的扩展");
            Add("guide.paste", "Ctrl+V", "Ctrl+V", "Ctrl+V");
            Add("guide.confirm", "Select folder", "Выбрать папку", "选择文件夹");
            Add("guide.stepno", "step {0} of 3", "шаг {0} из 3", "第 {0} 步, 共 3 步");
        }

        public static string Tr(string key)
        {
            string[] v;
            if (!T.TryGetValue(key, out v)) return key;
            int i = Lang == "ru" ? 1 : (Lang == "zh" ? 2 : 0);
            return v[i];
        }

        public static string F(string key, params object[] args)
        {
            try { return String.Format(Tr(key), args); }
            catch { return Tr(key); }
        }
    }

    public class BrowserInfo
    {
        public string Name;          // отображаемое имя
        public string VendorKey;     // Software\<VendorKey>\Extensions
        public string[] ExePaths;    // где искать исполняемый файл
        public string ExePath;       // найденный путь (null если нет)
        public string ExtPage;       // внутренняя страница дополнений
        public string UserDataDir;   // профиль браузера (для проверки установки)
        public bool Selected;

        public bool Found { get { return !String.IsNullOrEmpty(ExePath); } }
    }

    public class SetupForm : Form
    {
        /* ---------------- состояние ---------------- */

        readonly string targetDir = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "UndoBridge");
        string extDir { get { return Path.Combine(targetDir, "extension"); } }
        string agentDir { get { return Path.Combine(targetDir, "agent"); } }
        string agentExe { get { return Path.Combine(agentDir, "UndoBridgeAgent.exe"); } }
        string crxPath { get { return Path.Combine(targetDir, "undobridge.crx"); } }
        string keyPath { get { return Path.Combine(targetDir, "extension-key.xml"); } }

        List<BrowserInfo> browsers = new List<BrowserInfo>();
        List<BrowserInfo> installed = new List<BrowserInfo>();
        List<CheckBox> boxes = new List<CheckBox>();
        TextBox log;
        CheckBox optOpenPage, optClipboard, optShortcut, optAutostart;

        Panel stepsPanel;
        Label stepsTitle, stepsText;
        Button btnOpenPage, btnCopyPath, btnCheckSteps;

        /* контролы, которым меняем текст при смене языка */
        Label subLabel;
        GroupBox gbBrowserBox, gbOptBox;
        Button btnInstall, btnCheck, btnClose, btnCopyQuick, btnOpenNow;
        ComboBox langBox;

        /* пошаговая инструкция с картинками (переключается сама) */
        Panel guide;
        Label guideTitle, guideCaption;
        PictureBox guidePic;
        Timer guideTimer;
        int guideStep = 0;

        string extId = "";
        bool silent = false;

        /* ---------------- окно ---------------- */

        public SetupForm()
        {
            Text = L.Tr("win.title");
            ClientSize = new Size(620, 718);
            FormBorderStyle = FormBorderStyle.FixedSingle;
            MaximizeBox = false;
            StartPosition = FormStartPosition.CenterScreen;
            BackColor = Color.FromArgb(13, 17, 23);
            ForeColor = Color.FromArgb(215, 230, 222);
            Font = new Font("Segoe UI", 9f);

            Label title = new Label();
            title.Text = "UNDO BRIDGE";
            title.Font = new Font("Consolas", 16f, FontStyle.Bold);
            title.ForeColor = Color.FromArgb(46, 204, 113);
            title.SetBounds(16, 12, 400, 28);
            Controls.Add(title);

            /* переключатель языка — в правом верхнем углу */
            langBox = new ComboBox();
            langBox.DropDownStyle = ComboBoxStyle.DropDownList;
            langBox.Items.AddRange(new object[] { "English", "Русский", "中文" });
            langBox.SelectedIndex = 0;               // по умолчанию английский
            langBox.SetBounds(486, 12, 116, 24);
            langBox.SelectedIndexChanged += OnLangChanged;
            Controls.Add(langBox);

            subLabel = new Label();
            subLabel.Text = L.Tr("sub");
            subLabel.ForeColor = Color.FromArgb(138, 154, 165);
            subLabel.SetBounds(16, 42, 586, 38);
            Controls.Add(subLabel);

            gbBrowserBox = new GroupBox();
            gbBrowserBox.Text = L.Tr("gb.browser");
            gbBrowserBox.ForeColor = Color.FromArgb(215, 230, 222);
            gbBrowserBox.SetBounds(16, 84, 586, 124);
            Controls.Add(gbBrowserBox);

            FindBrowsers();
            int idx = 0;
            foreach (BrowserInfo b in browsers)
            {
                CheckBox cb = new CheckBox();
                cb.Text = b.Name + (b.Found ? "" : L.Tr("browser.missing"));
                cb.Checked = b.Found;
                cb.Enabled = b.Found;
                cb.Tag = b;
                int col = idx / 4;
                int row = idx % 4;
                cb.SetBounds(14 + col * 288, 18 + row * 25, 282, 22);
                cb.ForeColor = b.Found ? Color.FromArgb(215, 230, 222) : Color.FromArgb(120, 130, 138);
                gbBrowserBox.Controls.Add(cb);
                boxes.Add(cb);
                idx++;
            }

            gbOptBox = new GroupBox();
            gbOptBox.Text = L.Tr("gb.options");
            gbOptBox.ForeColor = Color.FromArgb(215, 230, 222);
            gbOptBox.SetBounds(16, 218, 586, 112);
            Controls.Add(gbOptBox);

            optOpenPage = MakeOption(gbOptBox, L.Tr("opt.open"), 20, true);
            optClipboard = MakeOption(gbOptBox, L.Tr("opt.clipboard"), 42, true);
            optShortcut = MakeOption(gbOptBox, L.Tr("opt.shortcut"), 64, true);
            optAutostart = MakeOption(gbOptBox, L.Tr("opt.autostart"), 86, true);

            btnInstall = new Button();
            btnInstall.Text = L.Tr("btn.install");
            btnInstall.Font = new Font("Consolas", 11f, FontStyle.Bold);
            btnInstall.SetBounds(16, 336, 278, 42);
            btnInstall.Click += OnInstall;
            Controls.Add(btnInstall);

            /* главная кнопка быстрого пути: папка уже разложена при открытии */
            btnCopyQuick = new Button();
            btnCopyQuick.Text = L.Tr("btn.copy.quick");
            btnCopyQuick.Font = new Font("Consolas", 10f, FontStyle.Bold);
            btnCopyQuick.SetBounds(304, 336, 298, 42);
            btnCopyQuick.Click += OnCopyQuick;
            Controls.Add(btnCopyQuick);

            btnCheck = new Button();
            btnCheck.Text = L.Tr("btn.check");
            btnCheck.SetBounds(16, 382, 182, 30);
            btnCheck.Click += OnCheck;
            Controls.Add(btnCheck);

            /* вернуться на страницу дополнений можно в любой момент */
            btnOpenNow = new Button();
            btnOpenNow.Text = L.Tr("btn.open.page");
            btnOpenNow.SetBounds(206, 382, 190, 30);
            btnOpenNow.Click += OnOpenPage;
            Controls.Add(btnOpenNow);

            btnClose = new Button();
            btnClose.Text = L.Tr("btn.close");
            btnClose.SetBounds(404, 382, 198, 30);
            btnClose.Click += delegate { Close(); };
            Controls.Add(btnClose);

            /* панель с шагами: появляется после установки */
            stepsPanel = new Panel();
            stepsPanel.SetBounds(16, 420, 586, 164);
            stepsPanel.BackColor = Color.FromArgb(17, 26, 32);
            stepsPanel.BorderStyle = BorderStyle.FixedSingle;
            stepsPanel.Visible = false;
            Controls.Add(stepsPanel);

            stepsTitle = new Label();
            stepsTitle.SetBounds(12, 8, 560, 20);
            stepsTitle.Font = new Font("Consolas", 9.5f, FontStyle.Bold);
            stepsTitle.ForeColor = Color.FromArgb(46, 204, 113);
            stepsPanel.Controls.Add(stepsTitle);

            stepsText = new Label();
            stepsText.SetBounds(12, 30, 560, 78);
            stepsText.ForeColor = Color.FromArgb(200, 214, 208);
            stepsPanel.Controls.Add(stepsText);

            btnOpenPage = MakeStepButton(stepsPanel, L.Tr("btn.step.open"), 12, 124, 186, OnOpenPage);
            btnCopyPath = MakeStepButton(stepsPanel, L.Tr("btn.step.copy"), 206, 124, 178, OnCopyPath);
            btnCheckSteps = MakeStepButton(stepsPanel, L.Tr("btn.step.check"), 392, 124, 182, OnCheck);

            /* пошаговая инструкция с картинками: кадры сменяются сами */
            guide = new Panel();
            guide.SetBounds(16, 420, 586, 164);
            guide.BackColor = Color.FromArgb(17, 26, 32);
            guide.BorderStyle = BorderStyle.FixedSingle;
            Controls.Add(guide);

            guideTitle = new Label();
            guideTitle.SetBounds(12, 8, 560, 20);
            guideTitle.Font = new Font("Consolas", 9.5f, FontStyle.Bold);
            guideTitle.ForeColor = Color.FromArgb(46, 204, 113);
            guide.Controls.Add(guideTitle);

            guidePic = new PictureBox();
            guidePic.SetBounds(12, 32, 562, 96);
            guidePic.BackColor = Color.FromArgb(10, 15, 19);
            guidePic.Cursor = Cursors.Hand;
            guidePic.Paint += PaintGuide;
            guidePic.Click += delegate { GuideNext(); };
            guide.Controls.Add(guidePic);

            guideCaption = new Label();
            guideCaption.SetBounds(12, 132, 560, 24);
            guideCaption.ForeColor = Color.FromArgb(200, 214, 208);
            guide.Controls.Add(guideCaption);

            guideTimer = new Timer();
            guideTimer.Interval = 4600;
            guideTimer.Tick += delegate { GuideNext(); };

            log = new TextBox();
            log.Multiline = true;
            log.ReadOnly = true;
            log.ScrollBars = ScrollBars.Vertical;
            log.SetBounds(16, 592, 586, 110);
            log.BackColor = Color.FromArgb(10, 15, 19);
            log.ForeColor = Color.FromArgb(160, 190, 175);
            log.Font = new Font("Consolas", 8.5f);
            log.BorderStyle = BorderStyle.FixedSingle;
            Controls.Add(log);

            Say(L.F("log.found", CountFound()));

            /* файлы раскладываем сразу: путь существует и готов к копированию */
            PrepareExtension();

            guideStep = 2;              // следующий вызов покажет первый кадр
            guideTimer.Start();
            GuideNext();
        }

        /* инструкция и шаги занимают одно место: до установки - картинки */
        void ShowGuide(bool on)
        {
            if (guide != null) guide.Visible = on;
            if (stepsPanel != null && on) stepsPanel.Visible = false;
            if (guideTimer != null)
            {
                if (on) guideTimer.Start();
                else guideTimer.Stop();
            }
        }

        void ApplyGuide()
        {
            if (guideTitle != null) guideTitle.Text = L.Tr("guide.title");
            if (guideCaption != null)
                guideCaption.Text = L.F("guide.stepno", guideStep + 1) + "    " + L.Tr("guide." + (guideStep + 1));
            if (guidePic != null) guidePic.Invalidate();
        }

        void GuideNext()
        {
            guideStep = (guideStep + 1) % 3;
            ApplyGuide();
        }

        /* Схемы шагов рисуем сами - внешние картинки не нужны. */
        void PaintGuide(object sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
            int w = guidePic.Width, h = guidePic.Height;

            using (Pen pLine = new Pen(Color.FromArgb(72, 94, 106)))
            using (Pen pAcc = new Pen(Color.FromArgb(46, 204, 113), 2f))
            using (SolidBrush bDim = new SolidBrush(Color.FromArgb(120, 138, 148)))
            using (SolidBrush bText = new SolidBrush(Color.FromArgb(205, 220, 214)))
            using (SolidBrush bAcc = new SolidBrush(Color.FromArgb(46, 204, 113)))
            using (SolidBrush bField = new SolidBrush(Color.FromArgb(22, 34, 40)))
            using (SolidBrush bBack = new SolidBrush(Color.FromArgb(16, 24, 30)))
            using (Font f = new Font("Segoe UI", 8.5f))
            using (Font fb = new Font("Consolas", 9f, FontStyle.Bold))
            {
                if (guideStep == 0)
                {
                    g.DrawRectangle(pLine, 10, 6, w - 20, h - 16);
                    g.DrawLine(pLine, 10, 25, w - 10, 25);
                    for (int i = 0; i < 3; i++) g.FillEllipse(bDim, 16 + i * 11, 13, 5, 5);

                    Rectangle bar = new Rectangle(28, 32, w - 56, 24);
                    g.FillRectangle(bBack, bar);
                    g.DrawRectangle(pAcc, bar);
                    g.DrawString(L.Tr("guide.bar"), fb, bText, bar.X + 8, bar.Y + 5);

                    g.FillPolygon(bAcc, new Point[] {
                        new Point(bar.Right - 34, bar.Y + 6), new Point(bar.Right - 34, bar.Y + 17),
                        new Point(bar.Right - 28, bar.Y + 14), new Point(bar.Right - 25, bar.Y + 20),
                        new Point(bar.Right - 21, bar.Y + 18), new Point(bar.Right - 24, bar.Y + 12),
                        new Point(bar.Right - 17, bar.Y + 12) });
                    g.DrawString("Enter", f, bAcc, bar.Right - 64, bar.Y + 5);
                }
                else if (guideStep == 1)
                {
                    g.DrawRectangle(pLine, 10, 6, w - 20, h - 16);
                    g.DrawString("Extensions", fb, bText, 20, 12);

                    Rectangle sw = new Rectangle(w - 218, 12, 34, 16);
                    g.FillRectangle(bAcc, sw);
                    g.FillEllipse(Brushes.White, sw.Right - 14, sw.Y + 2, 12, 12);
                    g.DrawString(L.Tr("guide.dev"), f, bAcc, w - 178, 13);

                    Rectangle btn = new Rectangle(20, 44, 210, 30);
                    g.FillRectangle(bField, btn);
                    g.DrawRectangle(pAcc, btn);
                    g.DrawString(L.Tr("guide.load"), fb, bAcc, btn.X + 10, btn.Y + 7);
                }
                else
                {
                    Rectangle dlg = new Rectangle(46, 6, w - 92, h - 16);
                    g.FillRectangle(bBack, dlg);
                    g.DrawRectangle(pLine, dlg);
                    g.DrawString(L.Tr("guide.confirm"), f, bText, dlg.X + 10, dlg.Y + 5);

                    Rectangle path = new Rectangle(dlg.X + 12, dlg.Y + 28, dlg.Width - 24, 22);
                    g.FillRectangle(bField, path);
                    g.DrawRectangle(pAcc, path);
                    g.DrawString("C:\\Users\\...\\UndoBridge\\extension", f, bText, path.X + 6, path.Y + 4);

                    Rectangle ok = new Rectangle(dlg.Right - 112, dlg.Bottom - 30, 100, 22);
                    g.FillRectangle(bAcc, ok);
                    g.DrawString(L.Tr("guide.confirm"), f, Brushes.Black, ok.X + 6, ok.Y + 3);

                    g.DrawString(L.Tr("guide.paste"), fb, bAcc, dlg.X + 12, dlg.Bottom - 27);
                }

                for (int i = 0; i < 3; i++)
                    g.FillEllipse(i == guideStep ? bAcc : bDim, w - 52 + i * 14, h - 15, 7, 7);
            }
        }

        void PrepareExtension()
        {
            try
            {
                if (!File.Exists(Path.Combine(extDir, "manifest.json")))
                {
                    ExtractExtension();
                    Say(L.F("say.prepared", extDir));
                }
            }
            catch (Exception ex) { Say(L.F("say.error", ex.Message)); }
        }

        /* копирование пути без установки: папка уже разложена при открытии */
        void OnCopyQuick(object sender, EventArgs e)
        {
            try
            {
                if (!Directory.Exists(extDir)) Directory.CreateDirectory(extDir);
                Clipboard.SetText(extDir);
                Say(L.Tr("say.copied.ok"));
            }
            catch (Exception ex) { Say(L.F("say.clip.err", ex.Message)); }
        }

        /* смена языка на лету: переключатель в правом верхнем углу */
        void OnLangChanged(object sender, EventArgs e)
        {
            L.Lang = langBox.SelectedIndex == 1 ? "ru" : (langBox.SelectedIndex == 2 ? "zh" : "en");
            ApplyLang();
        }

        void ApplyLang()
        {
            Text = L.Tr("win.title");
            if (subLabel != null) subLabel.Text = L.Tr("sub");
            if (gbBrowserBox != null) gbBrowserBox.Text = L.Tr("gb.browser");
            if (gbOptBox != null) gbOptBox.Text = L.Tr("gb.options");
            if (optOpenPage != null) optOpenPage.Text = L.Tr("opt.open");
            if (optClipboard != null) optClipboard.Text = L.Tr("opt.clipboard");
            if (optShortcut != null) optShortcut.Text = L.Tr("opt.shortcut");
            if (optAutostart != null) optAutostart.Text = L.Tr("opt.autostart");
            if (btnInstall != null) btnInstall.Text = L.Tr("btn.install");
            if (btnCheck != null) btnCheck.Text = L.Tr("btn.check");
            if (btnClose != null) btnClose.Text = L.Tr("btn.close");
            if (btnOpenNow != null) btnOpenNow.Text = L.Tr("btn.open.page");
            if (btnCopyQuick != null) btnCopyQuick.Text = L.Tr("btn.copy.quick");
            if (btnOpenPage != null) btnOpenPage.Text = L.Tr("btn.step.open");
            if (btnCopyPath != null) btnCopyPath.Text = L.Tr("btn.step.copy");
            if (btnCheckSteps != null) btnCheckSteps.Text = L.Tr("btn.step.check");
            foreach (CheckBox cb in boxes)
            {
                BrowserInfo b = cb.Tag as BrowserInfo;
                if (b != null) cb.Text = b.Name + (b.Found ? "" : L.Tr("browser.missing"));
            }
            ApplyGuide();
        }

        CheckBox MakeOption(GroupBox parent, string text, int y, bool value)
        {
            CheckBox cb = new CheckBox();
            cb.Text = text;
            cb.Checked = value;
            cb.SetBounds(14, y, 556, 22);
            cb.ForeColor = Color.FromArgb(215, 230, 222);
            parent.Controls.Add(cb);
            return cb;
        }

        Button MakeStepButton(Panel parent, string text, int x, int y, int w, EventHandler click)
        {
            Button b = new Button();
            b.Text = text;
            b.SetBounds(x, y, w, 30);
            b.Click += click;
            parent.Controls.Add(b);
            return b;
        }

        int CountFound()
        {
            int n = 0;
            foreach (BrowserInfo b in browsers) { if (b.Found) n++; }
            return n;
        }

        void Say(string s)
        {
            if (log == null) return;
            log.AppendText("> " + s + Environment.NewLine);
            try { log.SelectionStart = log.TextLength; log.ScrollToCaret(); } catch { }
        }

        /* ---------------- поиск браузеров ---------------- */

        void FindBrowsers()
        {
            browsers.Clear();

            string local = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
            string pf = Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles);
            string pf86 = Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86);

            BrowserInfo chrome = new BrowserInfo();
            chrome.Name = "Google Chrome";
            chrome.VendorKey = @"Software\Google\Chrome";
            chrome.ExtPage = "chrome://extensions/";
            chrome.UserDataDir = Path.Combine(local, @"Google\Chrome\User Data");
            chrome.ExePaths = new string[] {
                Combine(pf, @"Google\Chrome\Application\chrome.exe"),
                Combine(pf86, @"Google\Chrome\Application\chrome.exe"),
                Combine(local, @"Google\Chrome\Application\chrome.exe")
            };
            browsers.Add(chrome);

            BrowserInfo yandex = new BrowserInfo();
            yandex.Name = "Yandex Browser";
            yandex.VendorKey = @"Software\Yandex\YandexBrowser";
            yandex.ExtPage = "browser://extensions/";
            yandex.UserDataDir = Path.Combine(local, @"Yandex\YandexBrowser\User Data");
            yandex.ExePaths = new string[] {
                Combine(pf, @"Yandex\YandexBrowser\Application\browser.exe"),
                Combine(pf86, @"Yandex\YandexBrowser\Application\browser.exe"),
                Combine(local, @"Yandex\YandexBrowser\Application\browser.exe")
            };
            browsers.Add(yandex);

            BrowserInfo edge = new BrowserInfo();
            edge.Name = "Microsoft Edge";
            edge.VendorKey = @"Software\Microsoft\Edge";
            edge.ExtPage = "edge://extensions/";
            edge.UserDataDir = Path.Combine(local, @"Microsoft\Edge\User Data");
            edge.ExePaths = new string[] {
                Combine(pf86, @"Microsoft\Edge\Application\msedge.exe"),
                Combine(pf, @"Microsoft\Edge\Application\msedge.exe")
            };
            browsers.Add(edge);

            BrowserInfo opera = new BrowserInfo();
            opera.Name = "Opera";
            opera.VendorKey = @"Software\Opera Software\OperaStable";
            opera.ExtPage = "opera://extensions/";
            opera.UserDataDir = Path.Combine(local, @"Opera Software\Opera Stable");
            opera.ExePaths = new string[] {
                Combine(local, @"Programs\Opera\launcher.exe"),
                Combine(pf, @"Opera\launcher.exe"),
                Combine(pf86, @"Opera\launcher.exe"),
                Combine(local, @"Programs\Opera\opera.exe")
            };
            browsers.Add(opera);

            BrowserInfo operaGx = new BrowserInfo();
            operaGx.Name = "Opera GX";
            operaGx.VendorKey = @"Software\Opera Software\OperaGXStable";
            operaGx.ExtPage = "opera://extensions/";
            operaGx.UserDataDir = Path.Combine(local, @"Opera Software\Opera GX Stable");
            operaGx.ExePaths = new string[] {
                Combine(local, @"Programs\Opera GX\launcher.exe"),
                Combine(pf, @"Opera GX\launcher.exe"),
                Combine(local, @"Programs\Opera GX\opera.exe")
            };
            browsers.Add(operaGx);

            BrowserInfo brave = new BrowserInfo();
            brave.Name = "Brave";
            brave.VendorKey = @"Software\BraveSoftware\Brave-Browser";
            brave.ExtPage = "brave://extensions/";
            brave.UserDataDir = Path.Combine(local, @"BraveSoftware\Brave-Browser\User Data");
            brave.ExePaths = new string[] {
                Combine(pf, @"BraveSoftware\Brave-Browser\Application\brave.exe"),
                Combine(pf86, @"BraveSoftware\Brave-Browser\Application\brave.exe"),
                Combine(local, @"BraveSoftware\Brave-Browser\Application\brave.exe")
            };
            browsers.Add(brave);

            BrowserInfo vivaldi = new BrowserInfo();
            vivaldi.Name = "Vivaldi";
            vivaldi.VendorKey = @"Software\Vivaldi";
            vivaldi.ExtPage = "vivaldi://extensions/";
            vivaldi.UserDataDir = Path.Combine(local, @"Vivaldi\User Data");
            vivaldi.ExePaths = new string[] {
                Combine(pf, @"Vivaldi\Application\vivaldi.exe"),
                Combine(pf86, @"Vivaldi\Application\vivaldi.exe"),
                Combine(local, @"Vivaldi\Application\vivaldi.exe")
            };
            browsers.Add(vivaldi);

            BrowserInfo chromium = new BrowserInfo();
            chromium.Name = "Chromium";
            chromium.VendorKey = @"Software\Chromium";
            chromium.ExtPage = "chrome://extensions/";
            chromium.UserDataDir = Path.Combine(local, @"Chromium\User Data");
            chromium.ExePaths = new string[] {
                Combine(local, @"Chromium\Application\chrome.exe"),
                Combine(pf, @"Chromium\Application\chrome.exe")
            };
            browsers.Add(chromium);

            foreach (BrowserInfo b in browsers)
            {
                foreach (string p in b.ExePaths)
                {
                    try { if (p != null && File.Exists(p)) { b.ExePath = p; break; } }
                    catch { }
                }
                if (b.ExePath == null) { string r = FindInRegistry(b); if (r != null) b.ExePath = r; }
            }
        }

        static string Combine(string root, string tail)
        {
            if (String.IsNullOrEmpty(root)) return null;
            return Path.Combine(root, tail);
        }

        static string FindInRegistry(BrowserInfo b)
        {
            string want = Path.GetFileName(b.ExePaths[0]);
            string[] roots = new string[] {
                @"SOFTWARE\Clients\StartMenuInternet",
                @"SOFTWARE\WOW6432Node\Clients\StartMenuInternet"
            };
            foreach (string root in roots)
            {
                string sub = null;
                try
                {
                    using (RegistryKey baseKey = Registry.LocalMachine.OpenSubKey(root))
                    {
                        if (baseKey == null) continue;
                        foreach (string n in baseKey.GetSubKeyNames())
                        {
                            if (String.Equals(n, want, StringComparison.OrdinalIgnoreCase)) { sub = n; break; }
                        }
                    }
                }
                catch { continue; }
                if (sub == null) continue;
                try
                {
                    using (RegistryKey cmdKey = Registry.LocalMachine.OpenSubKey(root + @"\" + sub + @"\shell\open\command"))
                    {
                        if (cmdKey == null) continue;
                        string cmd = cmdKey.GetValue(null) as string;
                        if (String.IsNullOrEmpty(cmd)) continue;
                        string exe = cmd.Trim();
                        if (exe.StartsWith("\"")) { int e = exe.IndexOf('"', 1); if (e > 1) exe = exe.Substring(1, e - 1); }
                        else { int sp = exe.IndexOf(' '); if (sp > 0) exe = exe.Substring(0, sp); }
                        if (File.Exists(exe)) return exe;
                    }
                }
                catch { }
            }
            return null;
        }

        /* ---------------- установка ---------------- */

        List<BrowserInfo> CollectChosen()
        {
            List<BrowserInfo> chosen = new List<BrowserInfo>();
            foreach (CheckBox cb in boxes)
            {
                BrowserInfo b = cb.Tag as BrowserInfo;
                if (cb.Checked && b != null) { b.Selected = true; chosen.Add(b); }
            }
            return chosen;
        }

        void OnInstall(object sender, EventArgs e)
        {
            List<BrowserInfo> chosen = CollectChosen();
            if (chosen.Count == 0)
            {
                MessageBox.Show(this, L.Tr("msg.nobrowser"), L.Tr("msg.error.title"),
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            if (!InstallCore(chosen)) return;

            installed.Clear();
            installed.AddRange(chosen);
            ShowSteps(chosen);

            if (optOpenPage.Checked)
            {
                foreach (BrowserInfo b in chosen) OpenExtPage(b);
            }

            /* Яндекс не включает режим разработчика параметром в адресе, поэтому
               показываем подсказку поверх окон: где тумблер и куда вставлять путь. */
            if (!silent)
            {
                try { Clipboard.SetText(extDir); } catch { }
                MessageBox.Show(this, L.F("msg.hint", extDir), L.Tr("win.title"),
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        bool InstallCore(List<BrowserInfo> chosen)
        {
            try
            {
                Say(L.F("say.extdir", extDir));
                ExtractExtension();
                ExtractAgent();
                StartAgent();

                extId = BuildCrx();
                Say(L.F("say.id", extId, ExtVersion()));

                foreach (BrowserInfo b in chosen)
                {
                    try
                    {
                        RegisterExternal(b, extId);
                        Say(L.F("say.registry", b.Name));
                    }
                    catch (Exception ex) { Say(L.F("say.registry.err", b.Name, ex.Message)); }

                    if (optShortcut.Checked)
                    {
                        try { CreateShortcut(b); }
                        catch (Exception ex) { Say(L.F("say.shortcut.err", b.Name, ex.Message)); }
                    }
                }

                if (optAutostart.Checked) SetAutostart();

                if (optClipboard.Checked)
                {
                    try
                    {
                        Clipboard.SetText(extDir);
                        Say(L.Tr("say.clip"));
                    }
                    catch (Exception ex) { Say(L.F("say.clip.err", ex.Message)); }
                }

                Say(L.Tr("say.ready"));
                return true;
            }
            catch (Exception ex)
            {
                Say(L.F("say.error", ex.Message));
                if (!silent)
                {
                    MessageBox.Show(this, L.Tr("msg.fail.title") + "\n\n" + ex.Message, "Undo Bridge",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                return false;
            }
        }

        void ShowSteps(List<BrowserInfo> chosen)
        {
            StringBuilder names = new StringBuilder();
            foreach (BrowserInfo b in chosen)
            {
                if (names.Length > 0) names.Append(", ");
                names.Append(b.Name);
            }
            stepsTitle.Text = L.F("step.done", names.ToString());
            stepsText.Text = L.F("step.text", extDir,
                File.Exists(agentExe) ? L.Tr("step.agent.note") : "");
            /* после установки показываем шаги вместо картинок */
            if (guide != null) guide.Visible = false;
            if (guideTimer != null) guideTimer.Stop();
            stepsPanel.Visible = true;
        }

        void OpenExtPage(BrowserInfo b)
        {
            try
            {
                /* Открываем страницу как есть: с параметром ?devMode=true
                   Яндекс показывает стартовую вместо списка дополнений. */
                Process.Start(b.ExePath, b.ExtPage);
                Say(L.F("say.page.opened", b.Name));
            }
            catch (Exception ex) { Say(L.F("say.page.err", b.Name, ex.Message)); }
        }

        void OnOpenPage(object sender, EventArgs e)
        {
            List<BrowserInfo> list = installed.Count > 0 ? installed : CollectChosen();
            if (list.Count == 0) { Say(L.Tr("say.nobrowser.selected")); return; }
            foreach (BrowserInfo b in list) OpenExtPage(b);
        }

        void OnCopyPath(object sender, EventArgs e)
        {
            try
            {
                if (!Directory.Exists(extDir)) { Say(L.Tr("say.need.install")); return; }
                Clipboard.SetText(extDir);
                Say(L.F("say.copied", extDir));
            }
            catch (Exception ex) { Say(L.F("say.clip.err", ex.Message)); }
        }

        void OnCheck(object sender, EventArgs e)
        {
            List<BrowserInfo> list = installed.Count > 0 ? installed : CollectChosen();
            if (list.Count == 0) { Say(L.Tr("say.nothing.check")); return; }

            int ok = 0;
            foreach (BrowserInfo b in list)
            {
                string where;
                bool loaded = ExtensionLoaded(b, extId, out where);
                if (loaded) { ok++; Say(b.Name + ": " + L.F("state.loaded", where)); }
                else if (ProfilesOf(b.UserDataDir).Length == 0) Say(b.Name + ": " + L.Tr("state.noprofile"));
                else Say(b.Name + ": " + L.Tr("state.missing"));
            }

            if (ok == list.Count)
            {
                Say(L.Tr("say.allok"));
                stepsTitle.Text = L.Tr("step.ok.title");
                stepsText.Text = L.Tr("step.ok.text");
            }
            else
            {
                Say(L.Tr("say.ifnone"));
            }
        }

        /* ---------------- файлы и система ---------------- */

        void ExtractExtension()
        {
            Directory.CreateDirectory(targetDir);
            if (Directory.Exists(extDir))
            {
                try { Directory.Delete(extDir, true); } catch { }
            }
            Directory.CreateDirectory(extDir);

            Assembly asm = Assembly.GetExecutingAssembly();
            Stream src = asm.GetManifestResourceStream("UndoBridge.ext.zip");
            if (src == null) throw new Exception("в установщик не вложены файлы дополнения");

            string tmp = Path.Combine(targetDir, "ext-package.zip");
            using (FileStream fs = new FileStream(tmp, FileMode.Create, FileAccess.Write))
            {
                byte[] buf = new byte[81920];
                int n;
                while ((n = src.Read(buf, 0, buf.Length)) > 0) fs.Write(buf, 0, n);
            }
            src.Close();

            ZipFile.ExtractToDirectory(tmp, extDir);
            try { File.Delete(tmp); } catch { }

            int count = 0;
            try { count = Directory.GetFiles(extDir, "*", SearchOption.AllDirectories).Length; } catch { }
            Say(L.F("say.files", count));
        }

        /* Остановить движок: пока он работает, его exe занят и не заменяется. */
        void StopAgent()
        {
            for (int i = 0; i < 3; i++)
            {
                Process[] running = Process.GetProcessesByName("UndoBridgeAgent");
                if (running == null || running.Length == 0) return;
                foreach (Process p in running)
                {
                    try { p.Kill(); p.WaitForExit(4000); } catch { }
                }
                System.Threading.Thread.Sleep(400);
            }
        }

        /* Движок Undo — самодостаточный exe (собран PyInstaller), Python не нужен. */
        void ExtractAgent()
        {
            Assembly asm = Assembly.GetExecutingAssembly();
            Stream src = asm.GetManifestResourceStream("UndoBridge.agent.exe");
            if (src == null)
            {
                Say(L.Tr("say.agent.missing"));
                return;
            }
            Directory.CreateDirectory(agentDir);
            StopAgent();
            string tmp = agentExe + ".new";
            try { if (File.Exists(tmp)) File.Delete(tmp); } catch { }
            using (FileStream fs = new FileStream(tmp, FileMode.Create, FileAccess.Write))
            {
                byte[] buf = new byte[81920];
                int n;
                while ((n = src.Read(buf, 0, buf.Length)) > 0) fs.Write(buf, 0, n);
            }
            src.Close();

            bool ok = false;
            for (int i = 0; i < 6 && !ok; i++)
            {
                try
                {
                    if (File.Exists(agentExe)) File.Delete(agentExe);
                    File.Move(tmp, agentExe);
                    ok = true;
                }
                catch { System.Threading.Thread.Sleep(500); }
            }
            if (!ok)
            {
                try { File.Copy(tmp, agentExe, true); File.Delete(tmp); ok = true; }
                catch { }
            }
            if (ok) Say(L.F("say.agent.ok", agentExe));
            else Say(L.Tr("say.agent.busy"));
        }

        /* Запуск движка без окна: интерфейс живёт в дополнении. */
        void StartAgent()
        {
            if (!File.Exists(agentExe)) return;
            Process[] running = Process.GetProcessesByName("UndoBridgeAgent");
            if (running != null && running.Length > 0)
            {
                Say(L.Tr("say.agent.running"));
                return;
            }
            try
            {
                ProcessStartInfo psi = new ProcessStartInfo();
                psi.FileName = agentExe;
                psi.Arguments = "--headless";
                psi.WorkingDirectory = agentDir;
                psi.UseShellExecute = false;
                psi.CreateNoWindow = true;
                Process.Start(psi);
                Say(L.Tr("say.agent.started"));
            }
            catch (Exception ex) { Say(L.F("say.agent.err", ex.Message)); }
        }

        string ExtVersion()
        {
            try
            {
                string json = File.ReadAllText(Path.Combine(extDir, "manifest.json"), Encoding.UTF8);
                System.Text.RegularExpressions.Match m =
                    System.Text.RegularExpressions.Regex.Match(json, "\"version\"\\s*:\\s*\"([^\"]+)\"");
                if (m.Success) return m.Groups[1].Value;
            }
            catch { }
            return "1.0.0";
        }

        void RegisterExternal(BrowserInfo b, string id)
        {
            string key = b.VendorKey + @"\Extensions\" + id;
            using (RegistryKey rk = Registry.CurrentUser.CreateSubKey(key))
            {
                if (rk == null) throw new Exception("не удалось создать ключ " + key);
                rk.SetValue("path", crxPath, RegistryValueKind.String);
                rk.SetValue("version", ExtVersion(), RegistryValueKind.String);
            }
        }

        void CreateShortcut(BrowserInfo b)
        {
            string desktop = Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory);
            string lnk = Path.Combine(desktop, "DeepSeek + Undo (" + b.Name + ").lnk");
            object shell = null;
            try
            {
                Type t = Type.GetTypeFromProgID("WScript.Shell");
                if (t == null) throw new Exception("WScript.Shell недоступен");
                shell = Activator.CreateInstance(t);
                object sc = t.InvokeMember("CreateShortcut", BindingFlags.InvokeMethod, null, shell, new object[] { lnk });
                Type sct = sc.GetType();
                sct.InvokeMember("TargetPath", BindingFlags.SetProperty, null, sc, new object[] { b.ExePath });
                sct.InvokeMember("Arguments", BindingFlags.SetProperty, null, sc, new object[] { "https://chat.deepseek.com/" });
                sct.InvokeMember("WorkingDirectory", BindingFlags.SetProperty, null, sc, new object[] { Path.GetDirectoryName(b.ExePath) });
                sct.InvokeMember("Description", BindingFlags.SetProperty, null, sc, new object[] { "DeepSeek + Undo Bridge" });
                sct.InvokeMember("Save", BindingFlags.InvokeMethod, null, sc, null);
                Say(L.F("say.shortcut.ok", b.Name));
            }
            finally
            {
                if (shell != null) System.Runtime.InteropServices.Marshal.ReleaseComObject(shell);
            }
        }

        void SetAutostart()
        {
            string cmd;
            if (File.Exists(agentExe))
            {
                // наш собственный движок: стартует без окна вместе с Windows
                cmd = "\"" + agentExe + "\" --headless";
            }
            else
            {
                string undo = FindUndo();
                if (undo == null)
                {
                    Say(L.Tr("say.autostart.skip"));
                    return;
                }
                cmd = undo;
            }
            using (RegistryKey rk = Registry.CurrentUser.CreateSubKey(
                @"Software\Microsoft\Windows\CurrentVersion\Run"))
            {
                if (rk == null) { Say(L.Tr("say.autostart.noreg")); return; }
                rk.SetValue("UndoBridgeAgent", cmd, RegistryValueKind.String);
            }
            Say(L.F("say.autostart", cmd));
        }

        string FindUndo()
        {
            string local = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
            string[] candidates = new string[] {
                Path.Combine(local, @"Programs\Undo\Undo.exe"),
                Path.Combine(local, @"Undo\Undo.exe"),
                Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles), @"Undo\Undo.exe"),
                Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86), @"Undo\Undo.exe")
            };
            foreach (string c in candidates) { try { if (File.Exists(c)) return "\"" + c + "\""; } catch { } }

            string desktop = Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory);
            string[] scripts = new string[] {
                Path.Combine(desktop, @"undo\repo\Undo.py"),
                Path.Combine(desktop, @"undo\Undo.py")
            };
            foreach (string s in scripts)
            {
                try
                {
                    if (!File.Exists(s)) continue;
                    foreach (string pyw in Directory.GetFiles(
                        Path.Combine(local, @"Programs\Python"), "pythonw.exe", SearchOption.AllDirectories))
                    {
                        return "\"" + pyw + "\" \"" + s + "\"";
                    }
                }
                catch { }
            }
            return null;
        }

        /* ---------------- тихий режим ---------------- */

        public static int RunSilent(string want, bool shortcut)
        {
            SetupForm f = new SetupForm();
            f.silent = true;

            List<BrowserInfo> chosen = new List<BrowserInfo>();
            foreach (BrowserInfo b in f.browsers)
            {
                if (!b.Found) continue;
                if (!String.IsNullOrEmpty(want) && !Matches(b, want)) continue;
                chosen.Add(b);
            }

            f.optOpenPage.Checked = false;
            f.optClipboard.Checked = false;
            f.optAutostart.Checked = false;
            f.optShortcut.Checked = shortcut;

            bool ok = false;
            if (chosen.Count == 0) f.Say(L.Tr("say.silent.none"));
            else ok = f.InstallCore(chosen);

            try
            {
                Directory.CreateDirectory(f.targetDir);
                File.WriteAllText(Path.Combine(f.targetDir, "install.log"), f.log.Text, Encoding.UTF8);
            }
            catch { }
            return ok ? 0 : 1;
        }

        static bool Matches(BrowserInfo b, string want)
        {
            string w = want.ToLower();
            string id = "edge";
            if (b.VendorKey.IndexOf("Chrome", StringComparison.OrdinalIgnoreCase) >= 0) id = "chrome";
            else if (b.VendorKey.IndexOf("Yandex", StringComparison.OrdinalIgnoreCase) >= 0) id = "yandex";
            return w.IndexOf(id) >= 0 || w.IndexOf(b.Name.ToLower()) >= 0;
        }

        /* ---------------- проверка: загружено ли дополнение ---------------- */

        static string[] ProfilesOf(string userDataDir)
        {
            List<string> dirs = new List<string>();
            if (String.IsNullOrEmpty(userDataDir)) return dirs.ToArray();
            try
            {
                if (!Directory.Exists(userDataDir)) return dirs.ToArray();
                foreach (string d in Directory.GetDirectories(userDataDir))
                {
                    string name = Path.GetFileName(d);
                    if (String.Equals(name, "Default", StringComparison.OrdinalIgnoreCase)
                        || name.StartsWith("Profile", StringComparison.OrdinalIgnoreCase))
                        dirs.Add(d);
                }
            }
            catch { }
            return dirs.ToArray();
        }

        /* Ищем следы дополнения в профиле: путь к папке или id из CRX.
           Так видно и распакованное (загружено вручную), и внешнее из реестра. */
        static bool ExtensionLoaded(BrowserInfo b, string extId, out string where)
        {
            where = null;
            string[] profiles = ProfilesOf(b.UserDataDir);
            if (profiles.Length == 0) return false;
            foreach (string dir in profiles)
            {
                foreach (string f in new string[] { "Preferences", "Secure Preferences" })
                {
                    try
                    {
                        string p = Path.Combine(dir, f);
                        if (!File.Exists(p)) continue;
                        string text = File.ReadAllText(p);
                        if (text.IndexOf("UndoBridge", StringComparison.OrdinalIgnoreCase) >= 0)
                        {
                            where = Path.GetFileName(dir);
                            return true;
                        }
                        if (!String.IsNullOrEmpty(extId)
                            && text.IndexOf(extId, StringComparison.OrdinalIgnoreCase) >= 0)
                        {
                            where = Path.GetFileName(dir);
                            return true;
                        }
                    }
                    catch { }
                }
            }
            return false;
        }

        /* ---------------- CRX3: упаковка и подпись ---------------- */

        string BuildCrx()
        {
            string zip = Path.Combine(targetDir, "ext-package.zip");
            try { if (File.Exists(zip)) File.Delete(zip); } catch { }
            ZipFile.CreateFromDirectory(extDir, zip, CompressionLevel.Optimal, false);
            byte[] zipBytes = File.ReadAllBytes(zip);
            try { File.Delete(zip); } catch { }

            RSACryptoServiceProvider rsa = LoadOrCreateKey();
            byte[] pub = SubjectPublicKeyInfo(rsa);
            byte[] idBytes = ExtIdBytes(pub);
            string id = HexToId(idBytes);

            byte[] signedHeader = Field(1, idBytes);

            MemoryStream ms = new MemoryStream();
            byte[] magic = Encoding.ASCII.GetBytes("CRX3 SignedData");
            ms.Write(magic, 0, magic.Length);
            ms.WriteByte(0);
            byte[] hdrLen = LE32(signedHeader.Length);
            ms.Write(hdrLen, 0, hdrLen.Length);
            ms.Write(signedHeader, 0, signedHeader.Length);
            ms.Write(zipBytes, 0, zipBytes.Length);
            byte[] toSign = ms.ToArray();

            byte[] sig = rsa.SignData(toSign, "SHA256");

            byte[] proof = Concat(new byte[][] { Field(1, pub), Field(2, sig) });
            byte[] header = Concat(new byte[][] { Field(2, proof), Field(10000, signedHeader) });

            MemoryStream outMs = new MemoryStream();
            byte[] crxMagic = Encoding.ASCII.GetBytes("Cr24");
            outMs.Write(crxMagic, 0, 4);
            byte[] ver = LE32(3);
            outMs.Write(ver, 0, 4);
            byte[] hlen = LE32(header.Length);
            outMs.Write(hlen, 0, hlen.Length);
            outMs.Write(header, 0, header.Length);
            outMs.Write(zipBytes, 0, zipBytes.Length);

            File.WriteAllBytes(crxPath, outMs.ToArray());
            try { File.WriteAllText(Path.Combine(targetDir, "extension-id.txt"), id, Encoding.ASCII); } catch { }
            Say(L.F("say.packed", crxPath));
            return id;
        }

        RSACryptoServiceProvider LoadOrCreateKey()
        {
            RSACryptoServiceProvider rsa = new RSACryptoServiceProvider(2048);
            rsa.PersistKeyInCsp = false;
            try
            {
                if (File.Exists(keyPath))
                {
                    rsa.FromXmlString(File.ReadAllText(keyPath, Encoding.UTF8));
                    return rsa;
                }
            }
            catch { }
            try { File.WriteAllText(keyPath, rsa.ToXmlString(true), Encoding.UTF8); } catch { }
            return rsa;
        }

        static byte[] SubjectPublicKeyInfo(RSACryptoServiceProvider rsa)
        {
            RSAParameters p = rsa.ExportParameters(false);
            byte[] algId = Der(0x30, Concat(new byte[][] {
                Der(0x06, new byte[] { 0x2A, 0x86, 0x48, 0x86, 0xF7, 0x0D, 0x01, 0x01, 0x01 }),
                Der(0x05, new byte[0])
            }));
            byte[] rsaPub = Der(0x30, Concat(new byte[][] {
                DerInteger(p.Modulus),
                DerInteger(p.Exponent)
            }));
            byte[] bitString = Der(0x03, Concat(new byte[][] { new byte[] { 0x00 }, rsaPub }));
            return Der(0x30, Concat(new byte[][] { algId, bitString }));
        }

        static byte[] ExtIdBytes(byte[] spki)
        {
            using (SHA256 sha = SHA256.Create())
            {
                byte[] hash = sha.ComputeHash(spki);
                byte[] id = new byte[16];
                Array.Copy(hash, id, 16);
                return id;
            }
        }

        static string HexToId(byte[] id)
        {
            StringBuilder sb = new StringBuilder();
            foreach (byte b in id)
            {
                sb.Append((char)('a' + (b >> 4)));
                sb.Append((char)('a' + (b & 0x0F)));
            }
            return sb.ToString();
        }

        static byte[] LE32(int v)
        {
            return new byte[] { (byte)(v & 0xFF), (byte)((v >> 8) & 0xFF), (byte)((v >> 16) & 0xFF), (byte)((v >> 24) & 0xFF) };
        }

        static byte[] Varint(int value)
        {
            List<byte> b = new List<byte>();
            uint v = (uint)value;
            while (v >= 0x80) { b.Add((byte)((v & 0x7F) | 0x80)); v >>= 7; }
            b.Add((byte)v);
            return b.ToArray();
        }

        static byte[] Field(int number, byte[] payload)
        {
            return Concat(new byte[][] { Varint((number << 3) | 2), Varint(payload.Length), payload });
        }

        static byte[] Concat(byte[][] parts)
        {
            int total = 0;
            for (int i = 0; i < parts.Length; i++) total += parts[i].Length;
            byte[] outBuf = new byte[total];
            int pos = 0;
            for (int i = 0; i < parts.Length; i++)
            {
                Array.Copy(parts[i], 0, outBuf, pos, parts[i].Length);
                pos += parts[i].Length;
            }
            return outBuf;
        }

        static byte[] DerLen(int len)
        {
            if (len < 0x80) return new byte[] { (byte)len };
            if (len < 0x100) return new byte[] { 0x81, (byte)len };
            if (len < 0x10000) return new byte[] { 0x82, (byte)(len >> 8), (byte)(len & 0xFF) };
            return new byte[] { 0x83, (byte)(len >> 16), (byte)((len >> 8) & 0xFF), (byte)(len & 0xFF) };
        }

        static byte[] Der(byte tag, byte[] content)
        {
            return Concat(new byte[][] { new byte[] { tag }, DerLen(content.Length), content });
        }

        static byte[] DerInteger(byte[] bigEndian)
        {
            int i = 0;
            while (i < bigEndian.Length - 1 && bigEndian[i] == 0) i++;
            List<byte> body = new List<byte>();
            for (int k = i; k < bigEndian.Length; k++) body.Add(bigEndian[k]);
            if ((body[0] & 0x80) != 0) body.Insert(0, 0);
            return Der(0x02, body.ToArray());
        }
    }

    static class Program
    {
        [STAThread]
        static void Main(string[] args)
        {
            try
            {
                Application.EnableVisualStyles();
                Application.SetCompatibleTextRenderingDefault(false);

                bool silent = false;
                bool shortcut = false;
                string want = null;
                if (args != null)
                {
                    foreach (string a in args)
                    {
                        if (String.Equals(a, "--silent", StringComparison.OrdinalIgnoreCase)) silent = true;
                        else if (String.Equals(a, "--shortcut", StringComparison.OrdinalIgnoreCase)) shortcut = true;
                        else if (a.StartsWith("--browsers=", StringComparison.OrdinalIgnoreCase))
                            want = a.Substring("--browsers=".Length);
                    }
                }

                if (silent) { Environment.Exit(SetupForm.RunSilent(want, shortcut)); return; }

                Application.Run(new SetupForm());
            }
            catch (Exception e)
            {
                MessageBox.Show(e.ToString(), "Undo Bridge — ошибка");
            }
        }
    }
}
