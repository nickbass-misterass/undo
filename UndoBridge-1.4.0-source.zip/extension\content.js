/* Undo Bridge — content script.
   Мост между веб-чатом и локальным агентом Undo.

   Протокол Undo (манифест программы):
     1. ИИ пишет команду в блоке ```...```
     2. кнопка Copy кладёт команду в буфер обмена
     3. Undo опрашивает буфер каждые 700 мс и выполняет команду
     4. результат возвращается в буфер обмена
   Здесь весь цикл автоматизирован:
     блок -> буфер -> Undo -> результат -> поле ввода -> отправка в чат. */

(() => {
  if (window.__undoBridgeLoaded) return;
  window.__undoBridgeLoaded = true;

  const VERSION = (function () {
    try { return chrome.runtime.getManifest().version; } catch (e) { return "1.1.1"; }
  })();

  // Маркеры команд Undo — ровно как _CMD_RE в Undo.py
  const CMD_RE = /^(?:\/\/|<!--|#|--)?\s*(FILE|EDIT|APPEND|DELETE|CMD|MKDIR|COPY|MOVE|RENAME|TOUCH|TREE|READ|FIND|SEARCH|LIST|HEAD|TAIL|STAT|DIFF|COUNT|HASH|BACKUPS|RESTORE|CLEANUP|BACKUP_RULE|REMIND|CALC|CHECK|SNIPPET|CTX|NOTE|TASK|SHOT|LOG|REGEX):\s*(.*)$/i;

  // Надписи кнопки копирования: Copy, Copy code, Копировать, Скопировать, Копировать код, 复制代码.
  // Регистр и хвостовая пунктуация («Копировать:», «Copy.») не важны.
  const COPY_WORD_RE = /^(copy|copy to clipboard|копир[а-яё]*|скопир[а-яё]*|复制.*|複製.*)(\s*(code|код))?[\s:：.]*$/i;
  const COPY_ATTR_RE = /(copy|clipboard|копир|скопир|复制|複製)/i;

  const DEFAULTS = {
    enabled: true,
    autoRun: true,
    autoSend: true,
    showChip: true,
    lang: "auto",           // auto | en | ru | zh ("auto" — как в Undo)
    chipPos: null,          // { left, top } — куда перетащили панель
    chipCollapsed: false,
    chipLog: false,
    stableMs: 900,
    copyDelayMs: 350,
    pollMs: 350,
    resultTimeoutMs: 90000,
    cmdTimeoutMs: 1800000,   // CMD/PS: ждём до 30 минут, пока Undo не закончит
    maxSteps: 50,
    inputSelector: "",
    sendSelector: "",
    copySelector: ""
  };

  const cfg = Object.assign({}, DEFAULTS);
  const st = {
    stage: "idle",          // idle | copy | wait | send
    steps: 0,
    status: "wait",         // ключ перевода (см. i18n.js)
    error: false,
    paused: false,
    done: new WeakSet(),    // обработанные блоки кода
    stableSince: 0,
    stableText: "",
    lastMutation: Date.now(),
    busy: false,
    lines: []               // журнал для панели
  };

  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const log = (...a) => { try { console.log("[UndoBridge]", ...a); } catch (e) {} };

  /* ------------------------------------------------------------------ */
  /* язык интерфейса: en (по умолчанию), ru, zh; "auto" — как в Undo    */
  /* ------------------------------------------------------------------ */

  let curLang = "en";
  let T = (window.UB_I18N ? window.UB_I18N.make("en") : (k) => k);

  function applyLang(code) {
    const resolved = window.UB_I18N ? window.UB_I18N.resolve(code) : "en";
    if (resolved === curLang) return;
    curLang = resolved;
    T = window.UB_I18N ? window.UB_I18N.make(resolved) : ((k) => k);
    try { renderChip(); } catch (e) { /* панели ещё нет */ }
  }

  /* Спросить у Undo его язык (LANG:) и идти за ним в режиме auto. */
  async function syncLangFromUndo() {
    if (cfg.lang && cfg.lang !== "auto") { applyLang(cfg.lang); return; }
    try {
      await clipWrite("LANG:");
      for (let i = 0; i < 10; i++) {
        await sleep(220);
        const r = await clipRead();
        const m = /^\s*LANG:\s*(ru|en|zh)\b/i.exec(String(r || ""));
        if (m) { applyLang(m[1]); return; }
      }
    } catch (e) { /* Undo не запущен — остаёмся на en */ }
    applyLang("en");
  }

  /* Сохранить настройки: позиция панели, язык, режимы. */
  function saveCfgSoft() {
    try { chrome.storage.sync.set({ cfg: cfg }); } catch (e) { /* ignore */ }
  }

  /* Русские статусы -> ключи словаря: переводятся на en/zh автоматически. */
  const RU2KEY = {
    "ожидание": "wait",
    "ожидание (авто выкл.)": "wait",
    "ожидание команды Undo": "noCmd",
    "готов": "ready",
    "ждём конец ответа": "waitAnswer",
    "нажимаю «Продолжить»": "continue",
    "ждём продолжение ответа": "waitContinue",
    "код ещё дописывается": "waitAnswer",
    "команда уже отправлена": "alreadySent",
    "копирую команду": "copying",
    "не удалось положить команду в буфер обмена": "errBuffer",
    "Undo выполняет…": "waitUndo",
    "Undo не ответил — программа запущена?": "errUndo",
    "отправляю ответ в чат": "sending",
    "не удалось отправить ответ в чат": "errSend",
    "вставляю в поле ввода": "sending",
    "на странице нет блоков кода": "errPage",
    "последний блок — не команда Undo": "errNotCmd",
    "ручной запуск": "manual",
    "счётчик сброшен": "stepsReset",
    "пауза": "paused",
    "старт": "resume"
  };

  function tr(text) {
    const s = String(text == null ? "" : text);
    if (Object.prototype.hasOwnProperty.call(RU2KEY, s)) return T(RU2KEY[s]);
    let m = /^шаг\s+(\d+)/.exec(s);
    if (m) return T("step") + " " + m[1];
    m = /^лимит шагов\s+(\d+)/.exec(s);
    if (m) return T("limit") + " " + m[1];
    return T(s);
  }

  /* Строка в журнал панели — последние 30 событий. */
  function logLine(text) {
    try {
      const t = new Date();
      const hh = String(t.getHours()).padStart(2, "0");
      const mm = String(t.getMinutes()).padStart(2, "0");
      const ss = String(t.getSeconds()).padStart(2, "0");
      st.lines.push(hh + ":" + mm + ":" + ss + "  " + String(text).slice(0, 160));
      if (st.lines.length > 30) st.lines.splice(0, st.lines.length - 30);
      renderChip();
    } catch (e) { /* ignore */ }
  }

  /* ------------------------------------------------------------------ */
  /* настройки                                                          */
  /* ------------------------------------------------------------------ */

  function loadCfg() {
    try {
      chrome.storage.sync.get("cfg", (s) => {
        if (chrome.runtime.lastError) return;
        const v = (s && s.cfg) || {};
        Object.keys(DEFAULTS).forEach((k) => {
          if (v[k] !== undefined && v[k] !== null && v[k] !== "") cfg[k] = v[k];
          else if (v[k] === "" && typeof DEFAULTS[k] === "string") cfg[k] = "";
        });
        renderChip();
      });
    } catch (e) { /* расширение перезагружено */ }
  }

  try {
    chrome.storage.onChanged.addListener((ch, area) => {
      if (area === "sync" && ch.cfg) {
        Object.assign(cfg, DEFAULTS, ch.cfg.newValue || {});
        renderChip();
      }
    });
  } catch (e) { /* ignore */ }

  /* ------------------------------------------------------------------ */
  /* буфер обмена                                                       */
  /* ------------------------------------------------------------------ */

  function bg(msg) {
    return new Promise((resolve) => {
      try {
        chrome.runtime.sendMessage(msg, (reply) => {
          if (chrome.runtime.lastError) resolve(null);
          else resolve(reply || null);
        });
      } catch (e) { resolve(null); }
    });
  }

  async function clipWrite(text) {
    // 1. напрямую из страницы (быстро, работает когда вкладка в фокусе)
    try {
      await navigator.clipboard.writeText(text);
      return true;
    } catch (e) { /* нет фокуса или нет прав — идём в background */ }
    // 2. через offscreen документ расширения
    const r = await bg({ type: "clipWrite", text: text });
    return !!(r && r.ok);
  }

  async function clipRead() {
    try {
      const t = await navigator.clipboard.readText();
      if (typeof t === "string") return t;
    } catch (e) { /* страница не даёт читать — идём в background */ }
    const r = await bg({ type: "clipRead" });
    if (r && typeof r.text === "string") return r.text;
    return null;
  }

  async function badge(text, color) {
    await bg({ type: "badge", text: text, color: color });
  }

  /* ------------------------------------------------------------------ */
  /* вспомогательное                                                    */
  /* ------------------------------------------------------------------ */

  const norm = (s) => String(s == null ? "" : s).replace(/\r\n/g, "\n").replace(/\s+$/, "").trim();

  function firstLine(text) {
    const i = text.indexOf("\n");
    return i < 0 ? text : text.slice(0, i);
  }

  function isUndoCommand(text) {
    return CMD_RE.test(firstLine(norm(text)));
  }

  function visible(el) {
    if (!el || !el.isConnected) return false;
    const r = el.getBoundingClientRect();
    if (r.width < 2 && r.height < 2) return false;
    const cs = getComputedStyle(el);
    return cs.visibility !== "hidden" && cs.display !== "none" && cs.opacity !== "0";
  }

  function humanClick(el) {
    if (!el) return false;
    try { el.scrollIntoView({ block: "center" }); } catch (e) {}
    const r = el.getBoundingClientRect();
    const x = r.left + r.width / 2;
    const y = r.top + r.height / 2;
    const opts = { bubbles: true, cancelable: true, clientX: x, clientY: y, button: 0 };
    ["pointerover", "pointerenter", "pointerdown", "mousedown", "pointerup", "mouseup", "click"].forEach((t) => {
      const Ev = t.startsWith("pointer") && window.PointerEvent ? PointerEvent : MouseEvent;
      try { el.dispatchEvent(new Ev(t, opts)); } catch (e) {}
    });
    return true;
  }

  function pressEnter(el) {
    const mk = (type) => {
      const ev = new KeyboardEvent(type, {
        key: "Enter", code: "Enter", keyCode: 13, which: 13,
        bubbles: true, cancelable: true
      });
      try {
        Object.defineProperty(ev, "keyCode", { get: () => 13 });
        Object.defineProperty(ev, "which", { get: () => 13 });
      } catch (e) {}
      return ev;
    };
    el.dispatchEvent(mk("keydown"));
    el.dispatchEvent(mk("keypress"));
    el.dispatchEvent(mk("keyup"));
    return true;
  }

  /* ------------------------------------------------------------------ */
  /* блоки кода в чате                                                  */
  /* ------------------------------------------------------------------ */

  function codeBlocks() {
    const strict = [];
    const loose = [];
    const pres = document.querySelectorAll("pre");
    for (let i = 0; i < pres.length; i++) {
      const pre = pres[i];
      if (!visible(pre)) continue;
      const codeEl = pre.querySelector("code");
      const text = codeText(pre, codeEl);
      if (!text) continue;
      const item = { pre: pre, code: codeEl || pre, text: text, order: i };
      if (codeEl) strict.push(item);
      else loose.push(item);
    }
    // настоящий блок кода в чате всегда содержит <code>;
    // если таких нет — работаем с обычными <pre>
    return strict.length ? strict : loose;
  }

  function codeText(pre, codeEl) {
    let t = codeEl ? (codeEl.innerText || codeEl.textContent || "") : "";
    if (!t || !t.trim()) t = pre.innerText || pre.textContent || "";
    // Убираем возможные номера строк, которые рисует подсветка
    return String(t).replace(/\u00a0/g, " ").replace(/^\n+/, "").replace(/\n+$/, "");
  }

  function lastCodeBlock() {
    const all = codeBlocks();
    return all.length ? all[all.length - 1] : null;
  }

  /* Модели часто пишут «FILE: name.py» отдельной строкой ПЕРЕД блоком,
     а внутрь блока кладут чистый код. Понимаем и такой формат:
     достраиваем команду из маркера в тексте сообщения и содержимого блока. */
  function guessedFileCommand(block) {
    const code = String(block.text || "");
    if (!code.trim()) return null;
    const head = code.slice(0, 40).trim();
    let node = block.pre;
    for (let depth = 0; depth < 4 && node; depth++) {
      const full = node.innerText || "";
      const at = head ? full.indexOf(head) : -1;
      if (at > 0) {
        const before = full.slice(0, at);
        const m = before.match(/(?:^|\n)[ \t]*(?:\/\/|#|--)?[ \t]*FILE:[ \t]*([^\s`"']+)[ \t]*\n?$/i);
        if (m) return "FILE: " + m[1] + "\n" + code;
        break;
      }
      node = node.parentElement;
    }

    /* Модель совсем забыла маркер и выдала чистый код. Берём имя файла из
       просьбы человека («сделай файл game.py») — иначе блок бесполезен. */
    const name = fileNameFromChat();
    if (name && code.length > 60) return "FILE: " + name + "\n" + code;
    return null;
  }

  /* Имя файла, которое человек просил создать. Ищем в КОНЦЕ чата: манифест
     в начале переписки содержит примеры вроде hello.py и перебивал бы просьбу. */
  function fileNameFromChat() {
    let txt = "";
    try {
      const clone = document.body.cloneNode(true);
      const junk = clone.querySelectorAll("pre, svg, button");
      for (let i = 0; i < junk.length; i++) { try { junk[i].remove(); } catch (e) { /* ignore */ } }
      txt = clone.textContent || "";
    } catch (e) {
      txt = document.body.textContent || "";
    }
    const pick = function (s) {
      const re = /([A-Za-z0-9_\-\u0400-\u04FF]+\.(?:py|js|ts|json|txt|md|html|css|csv|bat|ps1|sh|yml|yaml))\b/g;
      const counts = {};
      let m;
      while ((m = re.exec(s))) counts[m[1]] = (counts[m[1]] || 0) + 1;
      let best = null;
      let bestN = 0;
      for (const k in counts) {
        if (counts[k] > bestN || (counts[k] === bestN && best && k.length < best.length)) {
          best = k;
          bestN = counts[k];
        }
      }
      return best;
    };
    const tail = txt.slice(-4000);
    return pick(tail) || pick(txt);
  }

  /* Кнопка Copy рядом с блоком.
     В DeepSeek структура меняется, поэтому ищем контейнер вокруг pre,
     внутри которого есть кнопка/иконка копирования. */
  function findCopyButton(pre) {
    const userSel = (cfg.copySelector || "").trim();
    if (userSel) {
      try {
        const scope = pre.parentElement || document;
        const el = scope.querySelector(userSel);
        if (el && visible(el)) return el;
      } catch (e) { /* плохой селектор */ }
    }

    let node = pre;
    for (let depth = 0; depth < 5 && node; depth++) {
      const hit = findCopyInside(node);
      if (hit) return hit;
      node = node.parentElement;
    }
    return null;
  }

  function findCopyInside(root) {
    if (!root || !root.querySelectorAll) return null;
    const cands = root.querySelectorAll("button, [role='button'], [class*='copy'], [id*='copy'], svg, span, div, a");
    let best = null;
    let bestSize = Infinity;
    for (let i = 0; i < cands.length; i++) {
      const el = cands[i];
      if (!visible(el)) continue;
      const label = norm(el.getAttribute && (el.getAttribute("aria-label") || el.getAttribute("title")) || "");
      const txt = norm(el.innerText || el.textContent || "");
      const cls = String((el.className && el.className.baseVal) || el.className || "") + " " +
                  String(el.id || "");
      let match = false;
      if (label && COPY_ATTR_RE.test(label)) match = true;
      else if (txt && COPY_WORD_RE.test(txt)) match = true;
      else if (cls && COPY_ATTR_RE.test(cls) && (el.tagName === "BUTTON" || el.getAttribute("role") === "button")) match = true;
      if (!match) continue;
      // берём самый маленький подходящий элемент — это и есть кнопка
      const r = el.getBoundingClientRect();
      const size = r.width * r.height;
      if (size > 0 && size < bestSize) { best = el; bestSize = size; }
    }
    return best;
  }

  function clickableCopy(pre) {
    const el = findCopyButton(pre);
    if (!el) return null;
    // если нашли иконку/подпись внутри кнопки — поднимаемся до самой кнопки
    try {
      const btn = el.closest ? el.closest("button, [role='button']") : null;
      if (btn) return btn;
    } catch (e) { /* ignore */ }
    return el;
  }

  /* ------------------------------------------------------------------ */
  /* поле ввода и кнопка отправки                                       */
  /* ------------------------------------------------------------------ */

  function getInput() {
    const sels = [];
    if ((cfg.inputSelector || "").trim()) sels.push(cfg.inputSelector.trim());
    sels.push(
      "textarea#chat-input",
      "textarea[placeholder]",
      "div[contenteditable='true'][role='textbox']",
      "div[contenteditable='true']",
      "textarea"
    );
    for (let i = 0; i < sels.length; i++) {
      let nodes;
      try { nodes = document.querySelectorAll(sels[i]); } catch (e) { continue; }
      for (let j = nodes.length - 1; j >= 0; j--) {
        const el = nodes[j];
        if (visible(el) && !el.disabled && !el.readOnly) return el;
      }
    }
    return null;
  }

  function inputEmpty(el) {
    if (!el) return true;
    const v = el.tagName === "TEXTAREA" || el.tagName === "INPUT" ? el.value : (el.innerText || "");
    return !norm(v);
  }

  function setInputText(el, text) {
    el.focus();
    if (el.tagName === "TEXTAREA" || el.tagName === "INPUT") {
      const proto = el.tagName === "TEXTAREA" ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
      const setter = Object.getOwnPropertyDescriptor(proto, "value").set;
      try { setter.call(el, text); } catch (e) { el.value = text; }
      el.dispatchEvent(new Event("input", { bubbles: true }));
      el.dispatchEvent(new Event("change", { bubbles: true }));
      return true;
    }
    // contenteditable (новая версия DeepSeek и другие чаты)
    try {
      const sel = window.getSelection();
      const range = document.createRange();
      range.selectNodeContents(el);
      sel.removeAllRanges();
      sel.addRange(range);
      document.execCommand("selectAll", false, null);
      const ok = document.execCommand("insertText", false, text);
      if (ok) return true;
    } catch (e) { /* ниже — грубый путь */ }
    el.textContent = text;
    el.dispatchEvent(new InputEvent("input", { bubbles: true, data: text, inputType: "insertText" }));
    return true;
  }

  function getSendButton(input) {
    const userSel = (cfg.sendSelector || "").trim();
    if (userSel) {
      try {
        const el = document.querySelector(userSel);
        if (el && visible(el)) return el;
      } catch (e) { /* ignore */ }
    }

    const labelRe = /(send|отправ|发送|отправить)/i;

    // 1. явная кнопка отправки по подписи
    const all = document.querySelectorAll("button, [role='button'], div[class*='send'], div[id*='send']");
    const near = [];
    for (let i = 0; i < all.length; i++) {
      const el = all[i];
      if (!visible(el)) continue;
      const label = norm((el.getAttribute("aria-label") || "") + " " + (el.getAttribute("title") || ""));
      const cls = String((el.className && el.className.baseVal) || el.className || "") + " " + String(el.id || "");
      if (labelRe.test(label) || /send/i.test(cls)) near.push(el);
    }
    if (near.length) {
      // из подходящих берём ближайший к полю ввода
      const ir = input.getBoundingClientRect();
      near.sort((a, b) => {
        const ra = a.getBoundingClientRect(), rb = b.getBoundingClientRect();
        const da = Math.abs(ra.top - ir.top) + Math.abs(ra.left - ir.right);
        const db = Math.abs(rb.top - ir.top) + Math.abs(rb.left - ir.right);
        return da - db;
      });
      return near[0];
    }

    // 2. submit внутри формы ввода
    const form = input.closest("form");
    if (form) {
      const sub = form.querySelector("button[type='submit'], input[type='submit']");
      if (sub && visible(sub)) return sub;
    }

    // 3. самая правая кнопка в контейнере ввода (send всегда справа)
    let box = input.parentElement;
    for (let i = 0; i < 4 && box; i++) {
      const btns = box.querySelectorAll("button, [role='button']");
      let best = null;
      let bestX = -Infinity;
      for (let j = 0; j < btns.length; j++) {
        const el = btns[j];
        if (!visible(el) || el === input || el.contains(input)) continue;
        const x = el.getBoundingClientRect().left;
        if (x > bestX) { bestX = x; best = el; }
      }
      if (best) return best;
      box = box.parentElement;
    }
    return null;
  }

  /* ------------------------------------------------------------------ */
  /* идёт ли ещё генерация ответа                                       */
  /* ------------------------------------------------------------------ */

  function findStopButton() {
    const all = document.querySelectorAll("button, [role='button']");
    for (let i = 0; i < all.length; i++) {
      const el = all[i];
      if (!visible(el)) continue;
      const label = norm((el.getAttribute("aria-label") || "") + " " + (el.getAttribute("title") || ""));
      const cls = String((el.className && el.className.baseVal) || el.className || "") + " " + String(el.id || "");
      if (/(stop|останов|стоп|停止)/i.test(label) || /(stop|abort)/i.test(cls)) return el;
    }
    return null;
  }

  function generationActive() {
    if (findStopButton()) return true;
    return Date.now() - st.lastMutation < 350;
  }

  /* DeepSeek часто обрывает длинный ответ и предлагает «Продолжить».
     Если эту кнопку не нажать, в буфер уедет только часть кода. */
  function findContinueButton() {
    const re = /^(continue|continue generating|продолжить|продолжить генерацию|продолжить ответ|сгенерировать ещё|продолжи|продолжение)$/i;
    const all = document.querySelectorAll("button, [role='button'], [class*='continue'], [class*='Continue'], [class*='contin']");
    let hit = null;
    for (let i = 0; i < all.length; i++) {
      const el = all[i];
      if (!visible(el)) continue;
      const txt = norm(el.innerText || el.textContent || "");
      const label = norm(el.getAttribute("aria-label") || el.getAttribute("title") || "");
      if (re.test(txt) || re.test(label)) hit = el;
    }
    return hit;
  }

  /* кнопка реально готова к нажатию: не disabled, не aria-disabled, видна */
  function isActionable(el) {
    if (!el || !visible(el)) return false;
    try {
      if (el.disabled) return false;
      if (String(el.getAttribute("aria-disabled") || "").toLowerCase() === "true") return false;
      if (String(el.getAttribute("disabled") || "").toLowerCase() === "true") return false;
      const r = el.getBoundingClientRect();
      return r.width > 4 && r.height > 4;
    } catch (e) {
      return false;
    }
  }

  /* ------------------------------------------------------------------ */
  /* основной цикл                                                      */
  /* ------------------------------------------------------------------ */

  async function tick() {
    if (st.busy) return;
    if (!cfg.enabled || st.paused) { setStatus(cfg.enabled ? "пауза" : "выключено"); return; }
    if (!cfg.autoRun) { setStatus("ожидание (авто выкл.)"); return; }
    if (document.hidden) { return; }

    const blocks = codeBlocks();
    if (!blocks.length) { setStatus("ожидание"); return; }

    if (!st.primed) {
      st.primed = true;
      st.nextIndex = blocks.length;     // всё, что было при открытии, — история
      setStatus("готов");
      return;
    }
    if (typeof st.nextIndex !== "number") st.nextIndex = blocks.length;
    if (st.nextIndex > blocks.length - 1) st.nextIndex = blocks.length - 1;

    if (generationActive()) { setStatus("ждём конец ответа"); st.stableSince = 0; return; }

    /* Ответ обрезан и предложено продолжить — жмём «Продолжить» и ждём дальше.
       Иначе скопируется только первая часть кода. */
    const cont = findContinueButton();
    if (cont) {
      const tNow = Date.now();
      st.stableSince = 0;
      st.stableText = "";
      if (!st.lastContinue || tNow - st.lastContinue > 2500) {
        st.lastContinue = tNow;
        humanClick(cont);
        setStatus("нажимаю «Продолжить»");
      } else {
        setStatus("ждём продолжение ответа");
      }
      return;
    }
    st.lastContinue = 0;

    /* ждём завершения именно последнего блока: он и дописывается */
    const lastText = norm(blocks[blocks.length - 1].text);
    if (st.stableText !== lastText) {
      st.stableText = lastText;
      st.stableSince = Date.now();
      setStatus("код ещё дописывается");
      return;
    }
    if (!st.stableSince) { st.stableSince = Date.now(); return; }
    if (Date.now() - st.stableSince < Number(cfg.stableMs || 900)) { setStatus("ждём конец ответа"); return; }

    if (st.steps >= Number(cfg.maxSteps || 50)) { setStatus("лимит шагов " + st.steps); return; }

    /* В одном ответе может быть несколько блоков — DeepSeek иногда присылает
       5-10 команд подряд. Берём первый необработанный и сдвигаем указатель,
       поэтому выполняются все, строго по порядку. */
    let block = null;
    let text = "";
    while (st.nextIndex < blocks.length) {
      const b = blocks[st.nextIndex];
      let t = norm(b.text);
      if (!isUndoCommand(t)) t = guessedFileCommand(b) || "";
      if (t) { block = b; text = t; break; }
      st.nextIndex++;                     // не команда — просто пропускаем
    }
    if (!block) { st.nextIndex = blocks.length; setStatus("ожидание команды Undo"); return; }

    st.done.add(block.pre);
    st.steps++;
    st.busy = true;
    st.error = false;
    try {
      await runFlow(block, text);
    } catch (e) {
      fail("сбой: " + (e && e.message ? e.message : e));
    } finally {
      st.busy = false;
      /* следующий блок этого же ответа — на следующем тике */
      if (typeof st.nextIndex === "number") st.nextIndex++;
    }
  }

  function same(a, b) { return norm(a) === norm(b); }

  async function runFlow(block, cmd) {
    const t0 = Date.now();

    /* 1. метка в буфере: гарантирует, что Undo увидит команду как новую
          (в Undo.py есть защита last_clip от повторного выполнения) */
    st.stage = "copy";
    setStatus("копирую команду");
    const poison = "__UNDO_BRIDGE__" + Date.now() + "_" + Math.random().toString(36).slice(2);
    await clipWrite(poison);
    await sleep(80);

    /* 2. жмём штатную кнопку Copy у блока (как это делает человек).
          Кнопка появляется раньше, чем становится активной, поэтому пробуем
          несколько раз и после каждой попытки проверяем, что буфер изменился. */
    const waits = [350, 600, 900, 1300];
    let clicked = false;
    let copied = false;
    let got = null;
    for (let attempt = 0; attempt < waits.length && !copied; attempt++) {
      const btn = clickableCopy(block.pre);
      if (btn && isActionable(btn)) {
        humanClick(btn);
        clicked = true;
      }
      await sleep(waits[attempt]);
      got = await clipRead();
      copied = same(got, cmd);
    }

    /* 3. страховка: если кнопка не сработала — кладём текст сами */
    let wrote = false;
    if (!copied) {
      wrote = await clipWrite(cmd);
      await sleep(150);
      got = await clipRead();
      copied = same(got, cmd);
    }

    /* Чтение буфера может быть недоступно без фокуса окна, хотя запись при
       этом проходит. Поэтому падаем только если не было ни клика, ни записи. */
    if (!copied && !clicked && !wrote) {
      fail("не удалось положить команду в буфер обмена");
      return;
    }

    /* 4. ждём, пока Undo выполнит команду и вернёт результат */
    st.stage = "wait";
    setStatus("Undo выполняет…");
    const result = await waitResult(cmd, poison);
    if (result === null) {
      fail("Undo не ответил — программа запущена?");
      return;
    }
    st.lastResult = result;

    /* 5. вставляем результат в поле ввода и отправляем */
    st.stage = "send";
    if (cfg.autoSend) {
      setStatus("отправляю ответ в чат");
      /* Скриншот Undo отдаёт меткой IMAGE: — такую картинку надо вставить
         файлом, иначе модель её не увидит. Остальное отправляем текстом. */
      const isImage = /^\s*IMAGE:\s*\S+?\.(?:png|jpe?g|gif|bmp|webp)/i.test(String(result));
      const ok = isImage ? await sendImageToChat(result) : await sendToChat(result);
      if (!ok) { fail("не удалось отправить ответ в чат"); return; }
    } else {
      setStatus("ответ в буфере — вставь вручную");
    }

    st.stage = "idle";
    st.stableText = "";
    st.stableSince = 0;
    setStatus("шаг " + st.steps + " готов · " + ((Date.now() - t0) / 1000).toFixed(1) + " с");
  }

  /* Ждём, пока вложение реально загрузится: в поле ввода появляется превью
     изображения, а кнопка отправки становится активной. */
  async function waitAttachReady(input, ms) {
    const t0 = Date.now();
    let sawAttach = false;
    while (Date.now() - t0 < ms) {
      let box = null;
      try {
        box = input.closest("form") ||
              (input.parentElement && input.parentElement.parentElement) ||
              document.body;
      } catch (e) { box = document.body; }

      let attach = null;
      try {
        attach = box ? box.querySelector(
          "img, [class*='attach'], [class*='upload'], [class*='file'], [class*='image'], [class*='thumb']"
        ) : null;
      } catch (e) { attach = null; }
      if (attach && visible(attach)) sawAttach = true;

      const btn = getSendButton(input);
      if (btn && isActionable(btn) && (sawAttach || Date.now() - t0 > 1500)) return true;
      await sleep(250);
    }
    return false;
  }

  /* Скриншот вставляем в чат как файл: берём картинку из системного буфера
     (Undo кладёт её туда вместе с меткой) и отправляем paste-событием —
     DeepSeek принимает изображение так же, как при Ctrl+V. */
  async function sendImageToChat(result) {
    const input = getInput();
    if (!input) return false;
    const path = (String(result).match(/IMAGE:\s*(\S+?\.(?:png|jpe?g|gif|bmp|webp))/i) || [])[1] || "";

    try {
      if (navigator.clipboard && navigator.clipboard.read) {
        const items = await navigator.clipboard.read();
        for (let i = 0; i < items.length; i++) {
          const types = items[i].types || [];
          for (let k = 0; k < types.length; k++) {
            if (types[k].indexOf("image/") !== 0) continue;
            const blob = await items[i].getType(types[k]);
            const ext = (types[k].split("/")[1] || "png").replace("jpeg", "jpg");
            const file = new File([blob], "shot." + ext, { type: types[k] });
            const dt = new DataTransfer();
            dt.items.add(file);
            input.focus();
            try {
              input.dispatchEvent(new ClipboardEvent("paste", {
                bubbles: true, cancelable: true, clipboardData: dt
              }));
            } catch (e) {
              /* некоторые движки не дают собрать ClipboardEvent — пробуем вручную */
              const ev = new Event("paste", { bubbles: true, cancelable: true });
              ev.clipboardData = dt;
              input.dispatchEvent(ev);
            }
            /* Картинка грузится в превью не мгновенно: кнопка отправки долго
               остаётся неактивной. Ждём, пока появится вложение И кнопка
               станет доступной, иначе отправка уходит в пустоту. */
            const ready = await waitAttachReady(input, 12000);
            if (!ready) {
              /* не дождались — вернём текст, чтобы не потерять результат */
              return sendToChat(path ? "Скриншот сохранён: " + path : String(result));
            }
            const send = getSendButton(input);
            if (send) humanClick(send); else pressEnter(input);
            await waitSent(input, 3000);
            await sleep(500);
            return true;
          }
        }
      }
    } catch (e) {
      /* нет разрешения на чтение буфера — уходим в текстовый запасной путь */
    }

    return sendToChat(path ? "Скриншот сохранён: " + path : String(result));
  }

  async function waitResult(cmd, poison) {
    const t0 = Date.now();
    /* Долгие команды (поиск/копирование файлов, сборки, установка) не обрываем:
       для CMD/PS/RUN действует отдельный длинный лимит. */
    const longCmd = /^\s*(?:CMD|PS|RUN)\s*:/i.test(String(cmd || ""));
    const limit = Number(longCmd ? (cfg.cmdTimeoutMs || 1800000) : (cfg.resultTimeoutMs || 90000));
    let prev = null;
    let stable = 0;
    while (Date.now() - t0 < limit) {
      await sleep(Number(cfg.pollMs) || 350);
      const cur = await clipRead();
      if (cur === null) continue;
      const c = String(cur);
      if (!c.trim()) continue;              // пустой буфер
      if (c === poison) continue;           // наша метка ещё не перезаписана
      if (same(c, cmd)) continue;           // команда ещё лежит в буфере
      const lm = /^\s*(?:UNDO_LANG|LANG)\s*:\s*(ru|en|zh)\b/i.exec(c);
      if (lm) { applyLang(lm[1]); continue; }   // Undo сменил язык
      // Undo пишет результат нескольких строк — ждём, пока он устоится
      if (prev !== null && c === prev) {
        stable++;
        if (stable >= 2) return c;
      } else {
        prev = c;
        stable = 0;
      }
    }
    return null;
  }

  async function waitSent(input, ms) {
    const t0 = Date.now();
    while (Date.now() - t0 < ms) {
      if (inputEmpty(input)) return true;
      if (findStopButton()) return true;
      await sleep(150);
    }
    return false;
  }

  async function sendToChat(text) {
    const input = getInput();
    if (!input) return false;
    setStatus("вставляю в поле ввода");
    input.focus();
    await sleep(60);
    setInputText(input, text);
    await sleep(200);
    if (inputEmpty(input)) return false;   // текст не вставился

    const btn = getSendButton(input);
    if (btn) {
      humanClick(btn);
      if (await waitSent(input, 2500)) return true;
    }
    pressEnter(input);
    return await waitSent(input, 2500);
  }

  function fail(msg) {
    st.error = true;
    st.stage = "idle";
    st.status = msg;
    logLine(tr(msg));
    log(msg);
  }

  /* ------------------------------------------------------------------ */
  /* панель статуса на странице                                         */
  /* ------------------------------------------------------------------ */

  let chip = null;
  let chipText = "";
  let chipClass = "";
  let lastBadge = "";

  function ensureChip() {
    if (!cfg.showChip) {
      if (chip && chip.isConnected) chip.remove();
      chip = null;
      return null;
    }
    if (chip && chip.isConnected) return chip;

    chip = document.createElement("div");
    chip.id = "ub-chip";

    const head = document.createElement("div");
    head.className = "ub-head";
    head.innerHTML =
      '<span class="ub-dot"></span>' +
      '<span class="ub-text"></span>' +
      '<button class="ub-act" data-act="pause"></button>' +
      '<button class="ub-act" data-act="run"></button>' +
      '<button class="ub-act" data-act="log">\u2261</button>' +
      '<button class="ub-act" data-act="collapse">\u2014</button>';
    chip.appendChild(head);

    const logBox = document.createElement("div");
    logBox.className = "ub-log";
    chip.appendChild(logBox);

    chip.addEventListener("click", (e) => {
      const act = e.target && e.target.getAttribute && e.target.getAttribute("data-act");
      if (!act) return;
      e.preventDefault();
      e.stopPropagation();
      if (act === "pause") {
        st.paused = !st.paused;
        logLine(st.paused ? T("paused") : T("resume"));
        renderChip();
      } else if (act === "run") {
        runNow();
      } else if (act === "log") {
        cfg.chipLog = !cfg.chipLog;
        saveCfgSoft();
        renderChip();
      } else if (act === "collapse") {
        cfg.chipCollapsed = !cfg.chipCollapsed;
        saveCfgSoft();
        renderChip();
      }
    });

    /* перетаскивание за шапку — позиция запоминается */
    let drag = null;
    head.addEventListener("mousedown", (e) => {
      if (e.target && e.target.getAttribute && e.target.getAttribute("data-act")) return;
      const r = chip.getBoundingClientRect();
      drag = { dx: e.clientX - r.left, dy: e.clientY - r.top };
      chip.classList.add("ub-drag");
      e.preventDefault();
    });
    document.addEventListener("mousemove", (e) => {
      if (!drag || !chip || !chip.isConnected) return;
      const w = chip.offsetWidth || 260;
      const h = chip.offsetHeight || 30;
      const left = Math.max(4, Math.min(window.innerWidth - w - 4, e.clientX - drag.dx));
      const top = Math.max(4, Math.min(window.innerHeight - h - 4, e.clientY - drag.dy));
      chip.style.left = left + "px";
      chip.style.top = top + "px";
      chip.style.right = "auto";
      chip.style.bottom = "auto";
    });
    document.addEventListener("mouseup", () => {
      if (!drag || !chip || !chip.isConnected) return;
      drag = null;
      chip.classList.remove("ub-drag");
      const r = chip.getBoundingClientRect();
      cfg.chipPos = { left: Math.round(r.left), top: Math.round(r.top) };
      saveCfgSoft();
    });

    document.documentElement.appendChild(chip);
    applyChipPos();
    return chip;
  }

  /* вернуть панель туда, куда её перетащили */
  function applyChipPos() {
    if (!chip) return;
    const p = cfg.chipPos;
    if (p && typeof p.left === "number" && typeof p.top === "number") {
      chip.style.left = p.left + "px";
      chip.style.top = p.top + "px";
      chip.style.right = "auto";
      chip.style.bottom = "auto";
    }
  }

  function setStatus(text) {
    if (st.error && text === st.status) return;
    const changed = text !== st.status;
    st.status = text;
    st.error = false;
    if (changed) logLine(tr(text));
    else renderChip();
  }

  function renderChip() {
    const c = ensureChip();
    if (!c) return;

    const collapsed = !!cfg.chipCollapsed;
    c.classList.toggle("ub-min", collapsed);

    let cls = "";
    if (!cfg.enabled || st.paused) cls = "ub-off";
    else if (st.error) cls = "ub-err";
    else if (st.stage !== "idle") cls = "ub-busy";
    if (cls !== chipClass) {
      c.classList.remove("ub-off", "ub-err", "ub-busy");
      if (cls) c.classList.add(cls);
      chipClass = cls;
    }

    const label = collapsed
      ? "UB " + String(st.steps || 0)
      : "Undo Bridge " + VERSION + " · " + tr(st.status);
    if (label !== chipText) {
      const span = c.querySelector(".ub-text");
      if (span) span.textContent = label;
      c.title = label;
      chipText = label;
    }

    const pb = c.querySelector("[data-act='pause']");
    if (pb) pb.textContent = st.paused || !cfg.enabled ? T("resume") : T("paused");
    const rb = c.querySelector("[data-act='run']");
    if (rb) rb.textContent = T("once");

    const logBox = c.querySelector(".ub-log");
    if (logBox) {
      const show = cfg.chipLog && !collapsed;
      logBox.style.display = show ? "block" : "none";
      if (show) {
        logBox.textContent = st.lines.slice(-14).join("\n") || T("wait");
        logBox.scrollTop = logBox.scrollHeight;
      }
    }

    let bText = String(st.steps || "");
    if (!cfg.enabled) bText = "";
    else if (st.error) bText = "!";
    else if (st.stage === "wait") bText = "…";
    const bColor = st.error ? "#b3403a" : st.stage === "wait" ? "#b8862b" : "#1f6f4a";
    const bKey = bText + "|" + bColor;
    if (bKey !== lastBadge) {
      lastBadge = bKey;
      try { badge(bText, bColor); } catch (e) { /* ignore */ }
    }
  }

  async function runNow() {
    st.paused = false;
    st.steps = 0;
    st.stableSince = 0;
    st.stableText = "";
    const block = lastCodeBlock();
    if (!block) { fail("на странице нет блоков кода"); return; }
    let text = norm(block.text);
    if (!isUndoCommand(text)) {
      text = guessedFileCommand(block);
      if (!text) { fail("последний блок — не команда Undo"); return; }
    }
    st.done.delete(block.pre);
    st.stableText = text;
    st.stableSince = Date.now() - Number(cfg.stableMs || 900) - 1;
    setStatus("ручной запуск");
    if (!st.busy) { st.steps++; st.busy = true; st.error = false;
      try { await runFlow(block, text); }
      catch (e) { fail("сбой: " + (e && e.message ? e.message : e)); }
      finally { st.busy = false; }
    }
  }

  /* Запросить у Undo длинный текст (манифест, контекст) через буфер. */
  async function askUndoText(command, timeoutMs, minLen, mustMatch) {
    try { await clipWrite(command); } catch (e) { return null; }
    const t0 = Date.now();
    let last = "";
    while (Date.now() - t0 < timeoutMs) {
      await sleep(400);
      const r = await clipRead();
      if (!r || r === command) continue;
      const s = String(r);
      if (s.length < minLen) continue;
      if (mustMatch && !mustMatch.test(s)) continue;
      if (s === last) return s;      // прочиталось дважды одинаково — готово
      last = s;
    }
    return last && last.length >= minLen ? last : null;
  }

  /* popup: вставить протокол Undo в чат одним сообщением. */
  async function insertManifest() {
    if (st.busy) return;
    st.busy = true;
    try {
      setStatus("вставляю манифест");
      const txt = await askUndoText("MANIFEST:", 25000, 200, /UNDO/i);
      if (!txt) { fail("не удалось получить манифест из Undo"); return; }
      const ok = await sendToChat(txt);
      logLine("manifest: " + txt.length + " chars, " + (ok ? "sent" : "failed"));
      setStatus("готово");
    } finally { st.busy = false; }
  }

  /* popup: собрать контекст проекта в Undo и отправить его в чат. */
  async function ctxToChat() {
    if (st.busy) return;
    st.busy = true;
    try {
      setStatus("сохраняю контекст");
      const txt = await askUndoText("CTX:", 90000, 60);
      if (!txt) { fail("не удалось получить контекст из Undo"); return; }
      const ok = await sendToChat(txt);
      logLine("ctx: " + txt.length + " chars, " + (ok ? "sent" : "failed"));
      setStatus("готово");
    } finally { st.busy = false; }
  }

  /* ------------------------------------------------------------------ */
  /* связь с popup                                                      */
  /* ------------------------------------------------------------------ */

  function snapshot() {
    return {
      ok: true,
      version: VERSION,
      cfg: cfg,
      stage: st.stage,
      steps: st.steps,
      paused: st.paused,
      error: st.error,
      status: st.status,
      lastResult: st.lastResult ? String(st.lastResult).slice(0, 400) : "",
      lines: (st.lines || []).slice(-40),
      hasCommand: (() => {
        const b = lastCodeBlock();
        return !!(b && isUndoCommand(b.text));
      })()
    };
  }

  try {
    chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
      if (!msg || !msg.type || msg.type.indexOf("ub:") !== 0) return;
      if (msg.type === "ub:state") { sendResponse(snapshot()); return false; }
      if (msg.type === "ub:toggle") {
        cfg.enabled = msg.value === undefined ? !cfg.enabled : !!msg.value;
        if (cfg.enabled) { st.paused = false; st.error = false; }
        setStatus(cfg.enabled ? "включено" : "выключено");
        sendResponse(snapshot());
        return false;
      }
      if (msg.type === "ub:pause") {
        st.paused = !!msg.value;
        setStatus(st.paused ? "пауза" : "ожидание");
        sendResponse(snapshot());
        return false;
      }
      if (msg.type === "ub:runNow") {
        runNow().then(() => sendResponse(snapshot()));
        return true;
      }
      if (msg.type === "ub:resetSteps") {
        st.steps = 0;
        setStatus("счётчик сброшен");
        sendResponse(snapshot());
        return false;
      }
      if (msg.type === "ub:setLang") {
        cfg.lang = String(msg.value || "auto");
        saveCfgSoft();
        if (cfg.lang === "auto") syncLangFromUndo();
        else applyLang(cfg.lang);
        sendResponse(snapshot());
        return false;
      }
      if (msg.type === "ub:insertManifest") {
        insertManifest().then(() => sendResponse(snapshot()));
        return true;
      }
      if (msg.type === "ub:ctxToChat") {
        ctxToChat().then(() => sendResponse(snapshot()));
        return true;
      }
      if (msg.type === "ub:chipLog") {
        cfg.chipLog = !!msg.value;
        saveCfgSoft();
        renderChip();
        sendResponse(snapshot());
        return false;
      }
      sendResponse({ ok: false, error: "unknown" });
      return false;
    });
  } catch (e) { /* ignore */ }

  /* ------------------------------------------------------------------ */
  /* старт                                                              */
  /* ------------------------------------------------------------------ */

  const obs = new MutationObserver((muts) => {
    for (let i = 0; i < muts.length; i++) {
      const t = muts[i].target;
      if (chip && (t === chip || (chip.contains && chip.contains(t)))) continue;
      st.lastMutation = Date.now();
      return;
    }
  });

  function boot() {
    loadCfg();
    try {
      obs.observe(document.body, { childList: true, subtree: true, characterData: true });
    } catch (e) { /* ignore */ }
    setInterval(() => { tick().catch(() => {}); }, 700);
    renderChip();
    /* язык: спросим у Undo, если в настройках стоит "как в Undo" */
    setTimeout(() => { syncLangFromUndo().catch(() => {}); }, 1500);
    log("готов, версия " + VERSION);
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", boot, { once: true });
  } else {
    boot();
  }
})();
