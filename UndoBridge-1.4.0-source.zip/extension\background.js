/* Undo Bridge — service worker.
   Задача: дать content script доступ к системному буферу обмена.
   Буфер — единственный канал связи с Undo (см. README Undo: опрос каждые 700 мс). */

const OFFSCREEN_URL = "offscreen.html";
let offscreenReady = false;
let creating = null;

async function hasOffscreen() {
  try {
    if (chrome.runtime.getContexts) {
      const ctx = await chrome.runtime.getContexts({
        contextTypes: ["OFFSCREEN_DOCUMENT"],
        documentUrls: [chrome.runtime.getURL(OFFSCREEN_URL)]
      });
      return ctx && ctx.length > 0;
    }
  } catch (e) { /* старые сборки */ }
  return offscreenReady;
}

async function ensureOffscreen() {
  if (await hasOffscreen()) { offscreenReady = true; return true; }
  if (!chrome.offscreen || !chrome.offscreen.createDocument) return false;
  if (creating) { await creating; return offscreenReady; }
  creating = (async () => {
    try {
      await chrome.offscreen.createDocument({
        url: OFFSCREEN_URL,
        reasons: ["CLIPBOARD"],
        justification: "Чтение результата Undo и запись команды в системный буфер обмена"
      });
      offscreenReady = true;
    } catch (e) {
      // "Only a single offscreen document may be created" — значит уже есть
      const msg = String(e && e.message || e);
      if (msg.indexOf("single offscreen") >= 0) offscreenReady = true;
      else offscreenReady = false;
    } finally {
      creating = null;
    }
  })();
  await creating;
  return offscreenReady;
}

function toOffscreen(payload) {
  return new Promise((resolve) => {
    let done = false;
    const timer = setTimeout(() => { if (!done) { done = true; resolve(null); } }, 4000);
    try {
      chrome.runtime.sendMessage(payload, (reply) => {
        if (done) return;
        done = true;
        clearTimeout(timer);
        if (chrome.runtime.lastError) resolve(null);
        else resolve(reply || null);
      });
    } catch (e) {
      done = true;
      clearTimeout(timer);
      resolve(null);
    }
  });
}

async function clipWrite(text) {
  const ok = await ensureOffscreen();
  if (!ok) return { ok: false, reason: "no-offscreen" };
  const r = await toOffscreen({ to: "offscreen", cmd: "write", text: String(text == null ? "" : text) });
  return r || { ok: false, reason: "no-reply" };
}

async function clipRead() {
  const ok = await ensureOffscreen();
  if (!ok) return { ok: false, reason: "no-offscreen" };
  const r = await toOffscreen({ to: "offscreen", cmd: "read" });
  return r || { ok: false, reason: "no-reply" };
}

function setBadge(text, color) {
  try {
    chrome.action.setBadgeText({ text: text || "" });
    if (color) chrome.action.setBadgeBackgroundColor({ color: color });
  } catch (e) { /* ignore */ }
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!msg || msg.to === "offscreen") return; // не наше

  if (msg.type === "clipWrite") {
    clipWrite(msg.text).then((r) => sendResponse(r));
    return true;
  }
  if (msg.type === "clipRead") {
    clipRead().then((r) => sendResponse(r));
    return true;
  }
  if (msg.type === "badge") {
    setBadge(msg.text, msg.color);
    sendResponse({ ok: true });
    return false;
  }
  return false;
});

chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.sync.get("cfg", (s) => {
    if (!s || !s.cfg) {
      chrome.storage.sync.set({
        cfg: {
          enabled: true,
          autoRun: true,
          autoSend: true,
          showChip: true,
          stableMs: 900,
          copyDelayMs: 350,
          pollMs: 350,
          resultTimeoutMs: 90000,
          maxSteps: 12,
          inputSelector: "",
          sendSelector: "",
          copySelector: ""
        }
      });
    }
  });
  setBadge("", null);
});
