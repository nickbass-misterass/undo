/* Undo Bridge — дополнение к popup.js для полноценной боковой панели:
   тянет журнал событий у content script и печатает его целиком. */
(function () {
  const big = document.getElementById("biglog");
  if (!big) return;

  let tabId = null;

  async function findTab() {
    try {
      const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
      tabId = tabs && tabs[0] ? tabs[0].id : null;
    } catch (e) {
      tabId = null;
    }
  }

  function send(msg) {
    return new Promise((res) => {
      if (tabId === null) { res(null); return; }
      try {
        chrome.tabs.sendMessage(tabId, msg, (r) => {
          if (chrome.runtime.lastError) { res(null); return; }
          res(r || null);
        });
      } catch (e) { res(null); }
    });
  }

  async function pull() {
    if (tabId === null) await findTab();
    const s = await send({ type: "ub:state" });
    if (!s || !s.lines) { big.textContent = "—"; return; }
    const text = s.lines.join("\n");
    if (big.textContent !== text) {
      big.textContent = text;
      big.scrollTop = big.scrollHeight;
    }
  }

  findTab().then(pull);
  setInterval(pull, 1200);
})();
