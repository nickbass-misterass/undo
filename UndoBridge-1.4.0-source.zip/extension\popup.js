/* Undo Bridge — логика popup */

const $ = (id) => document.getElementById(id);

const FIELDS = {
  enabled: "checked",
  autoRun: "checked",
  autoSend: "checked",
  showChip: "checked",
  stableMs: "number",
  maxSteps: "number"
};

let cfg = {};
let tabId = null;

/* строки popup: en по умолчанию, ru, zh */
const POP = {
  en: {
    mode: "Mode", timings: "Timings", control: "Control", last: "Last result",
    language: "Language", langLabel: "interface", langAuto: "same as Undo",
    langNote: "\"Same as Undo\" — the extension asks Undo for its language and follows it.",
    enabled: "enabled", autoRun: "auto: run commands from the chat",
    autoSend: "auto: send the answer back", showChip: "show the panel on the page",
    stableLbl: "wait for the end of the answer, ms", timeoutLbl: "wait for Undo answer",
    limitLbl: "step limit",
    timeoutNote: "1.5 min by default: heavy commands fit, and a stopped Undo does not hang the bridge.",
    btnRun: "Run now", btnReset: "Reset steps", btnManifest: "Insert manifest",
    btnCtx: "Context to chat", btnOpen: "Open DeepSeek", btnReload: "Reload tab",
    btnPanel: "Open side panel", logTitle: "What happens",
    hint1: "Undo must be running: it reads the clipboard every 700 ms.",
    hint2: "The command is taken from the last code block of the answer.",
    inactive: "Extension is not active on this tab", inactive2: "Open the chat or reload the page.",
    step: "step", hasCmd: "the chat has an Undo command",
    stIdle: "waiting", stCopy: "copying", stWait: "waiting for Undo", stSend: "sending"
  },
  ru: {
    mode: "Режим", timings: "Тайминги", control: "Управление", last: "Последний результат",
    language: "Язык", langLabel: "интерфейс", langAuto: "как в Undo",
    langNote: "«Как в Undo» — расширение спрашивает язык у Undo и переключается вместе с ним.",
    enabled: "включено", autoRun: "авто: выполнять команды из чата",
    autoSend: "авто: отправлять ответ в чат", showChip: "показывать панель на странице",
    stableLbl: "ждать конец ответа, мс", timeoutLbl: "сколько ждать ответ Undo",
    limitLbl: "лимит шагов",
    timeoutNote: "По умолчанию 1,5 минуты: тяжёлые команды успевают, а при выключенном Undo мост не висит долго.",
    btnRun: "Запустить сейчас", btnReset: "Сброс шагов", btnManifest: "Вставить манифест",
    btnCtx: "Контекст в чат", btnOpen: "Открыть DeepSeek", btnReload: "Перезагрузить вкладку",
    btnPanel: "Открыть панель", logTitle: "Что происходит",
    hint1: "Undo должен быть запущен: он читает буфер каждые 700 мс.",
    hint2: "Команда берётся из последнего блока кода в ответе.",
    inactive: "Расширение не активно на этой вкладке", inactive2: "Открой чат или обнови страницу.",
    step: "шаг", hasCmd: "в чате есть команда Undo",
    stIdle: "ожидание", stCopy: "копирование", stWait: "ждём Undo", stSend: "отправка"
  },
  zh: {
    mode: "模式", timings: "时序", control: "控制", last: "最近结果",
    language: "语言", langLabel: "界面", langAuto: "与 Undo 一致",
    langNote: "“与 Undo 一致” — 扩展会向 Undo 询问语言并跟随切换。",
    enabled: "已启用", autoRun: "自动：执行聊天中的命令",
    autoSend: "自动：把答案发回聊天", showChip: "在页面上显示面板",
    stableLbl: "等待回答结束，毫秒", timeoutLbl: "等待 Undo 回答",
    limitLbl: "步骤上限",
    timeoutNote: "默认 1.5 分钟：重命令来得及，Undo 未启动时也不会长时间挂起。",
    btnRun: "立即运行", btnReset: "重置步骤", btnManifest: "插入清单",
    btnCtx: "上下文到聊天", btnOpen: "打开 DeepSeek", btnReload: "刷新标签页",
    btnPanel: "打开侧边栏", logTitle: "正在发生什么",
    hint1: "Undo 必须运行：它每 700 毫秒读取剪贴板。",
    hint2: "命令取自回答中最后一个代码块。",
    inactive: "扩展在此标签页未激活", inactive2: "打开聊天或刷新页面。",
    step: "步骤", hasCmd: "聊天中有 Undo 命令",
    stIdle: "等待", stCopy: "复制中", stWait: "等待 Undo", stSend: "发送中"
  }
};

let T = (k) => (POP.en && POP.en[k]) || k;

function applyPopupLang(code) {
  const lang = (window.UB_I18N ? window.UB_I18N.resolve(code) : "en");
  T = (k) => (POP[lang] && POP[lang][k]) || POP.en[k] || k;
  document.documentElement.lang = lang;
  const map = [
    ["h2", "mode"], ["h2", "timings"], ["h2", "control"], ["h2", "last"]
  ];
  /* статические подписи: ищем по русскому тексту */
  const RU = POP.ru;
  const nodes = document.querySelectorAll("h2, label.row, .field span, .note, button.act, .hint");
  for (let i = 0; i < nodes.length; i++) {
    const el = nodes[i];
    const key = el.getAttribute("data-i18n");
    if (key) {
      const val = T(key);
      if (val) el.textContent = val;
      continue;
    }
    const txt = (el.textContent || "").trim();
    const found = Object.keys(RU).filter((k) => RU[k] === txt)[0];
    if (found) el.textContent = T(found);
  }
}

function loadCfg() {
  return new Promise((resolve) => {
    chrome.storage.sync.get("cfg", (s) => {
      cfg = (s && s.cfg) || {};
      resolve(cfg);
    });
  });
}

function saveCfg() {
  chrome.storage.sync.set({ cfg: cfg });
}

function paint() {
  $("enabled").checked = cfg.enabled !== false;
  $("autoRun").checked = cfg.autoRun !== false;
  $("autoSend").checked = cfg.autoSend !== false;
  $("showChip").checked = cfg.showChip !== false;
  $("stableMs").value = Number(cfg.stableMs || 900);
  $("maxSteps").value = Number(cfg.maxSteps || 12);
  $("timeoutSec").value = String(Math.round(Number(cfg.resultTimeoutMs || 90000) / 1000));
  if ($("lang")) $("lang").value = cfg.lang || "auto";
  applyPopupLang(cfg.lang || "auto");
  $("ver").textContent = "v" + (chrome.runtime.getManifest().version || "1.0.0");
  $("lastres").textContent = "—";
}

function send(msg) {
  return new Promise((resolve) => {
    if (tabId === null) { resolve(null); return; }
    chrome.tabs.sendMessage(tabId, msg, (reply) => {
      if (chrome.runtime.lastError) { resolve(null); return; }
      resolve(reply || null);
    });
  });
}

function showStatus(s) {
  const dot = $("dot");
  dot.className = "dot";
  if (!s) {
    $("status").innerHTML = "<b>" + T("inactive") + "</b><br>" + T("inactive2");
    dot.className = "dot off";
    return;
  }
  if (!s.cfg || s.cfg.enabled === false) dot.className = "dot off";
  else if (s.error) dot.className = "dot err";
  const stageKey = { idle: "stIdle", copy: "stCopy", wait: "stWait", send: "stSend" };
  $("status").innerHTML =
    "<b>" + T(stageKey[s.stage] || "stIdle") + "</b> · " + T("step") + " " + (s.steps || 0) +
    "<br>" + escapeHtml(s.status || "") +
    (s.hasCommand ? "<br>" + T("hasCmd") : "");
  if (s.lastResult) $("lastres").textContent = s.lastResult;
}

function escapeHtml(s) {
  return String(s).replace(/[&<>]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;" }[c]));
}

async function refresh() {
  const s = await send({ type: "ub:state" });
  showStatus(s);
  return s;
}

function bind() {
  Object.keys(FIELDS).forEach((k) => {
    const el = $(k);
    if (!el) return;
    el.addEventListener("change", () => {
      if (FIELDS[k] === "checked") {
        cfg[k] = el.checked;
        if (k === "enabled") send({ type: "ub:toggle", value: el.checked });
        if (k === "showChip") send({ type: "ub:state" });
      } else {
        cfg[k] = Number(el.value) || 0;
        if (k === "stableMs") cfg.stableMs = Math.max(300, cfg.stableMs);
        if (k === "maxSteps") cfg.maxSteps = Math.max(1, cfg.maxSteps);
      }
      saveCfg();
      refresh();
    });
  });

  $("timeoutSec").addEventListener("change", () => {
    const sec = Math.max(30, Number($("timeoutSec").value) || 90);
    cfg.resultTimeoutMs = sec * 1000;
    saveCfg();
    refresh();
  });

  $("runNow").addEventListener("click", async () => {
    const s = await send({ type: "ub:runNow" });
    showStatus(s);
    setTimeout(refresh, 1000);
  });

  $("reset").addEventListener("click", async () => {
    const s = await send({ type: "ub:resetSteps" });
    showStatus(s);
  });

  $("openChat").addEventListener("click", () => {
    chrome.tabs.create({ url: "https://chat.deepseek.com/" });
  });

  $("reload").addEventListener("click", () => {
    if (tabId !== null) chrome.tabs.reload(tabId);
    window.close();
  });

  const op = $("openPanel");
  if (op) {
    op.addEventListener("click", async () => {
      try {
        if (tabId !== null) await chrome.sidePanel.open({ tabId: tabId });
        else await chrome.sidePanel.open({ windowId: chrome.windows.WINDOW_ID_CURRENT });
      } catch (e) {
        /* панель недоступна в этой версии браузера — остаёмся в popup */
      }
      window.close();
    });
  }

  const langSel = $("lang");
  if (langSel) {
    langSel.addEventListener("change", async () => {
      cfg.lang = langSel.value;
      saveCfg();
      applyPopupLang(cfg.lang);
      await send({ type: "ub:setLang", value: cfg.lang });
      refresh();
    });
  }

  const mf = $("insertManifest");
  if (mf) {
    mf.addEventListener("click", async () => {
      mf.disabled = true;
      const s = await send({ type: "ub:insertManifest" });
      showStatus(s);
      setTimeout(() => { mf.disabled = false; refresh(); }, 1500);
    });
  }

  const cx = $("ctxToChat");
  if (cx) {
    cx.addEventListener("click", async () => {
      cx.disabled = true;
      const s = await send({ type: "ub:ctxToChat" });
      showStatus(s);
      setTimeout(() => { cx.disabled = false; refresh(); }, 1500);
    });
  }
}

async function init() {
  await loadCfg();
  paint();
  bind();

  const tabs = await new Promise((r) => chrome.tabs.query({ active: true, currentWindow: true }, r));
  const tab = tabs && tabs[0];
  tabId = tab ? tab.id : null;

  await refresh();
  setTimeout(refresh, 600);
}

init();
