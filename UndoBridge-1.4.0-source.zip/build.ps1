﻿# Undo Bridge — сборка установщика.
# Требуется только .NET Framework 4.x (csc.exe входит в Windows).

$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $MyInvocation.MyCommand.Definition
$ext  = Join-Path $root 'extension'
$inst = Join-Path $root 'installer'
$out  = Join-Path $root 'dist'
$work = Join-Path $root 'build'

New-Item -ItemType Directory -Force -Path $out, $work | Out-Null

# ---------- 1. иконки ----------
Add-Type -AssemblyName System.Drawing
$iconDir = Join-Path $ext 'icons'
New-Item -ItemType Directory -Force -Path $iconDir | Out-Null

foreach ($s in 16, 48, 128) {
    $path = Join-Path $iconDir ("icon{0}.png" -f $s)
    $bmp = New-Object System.Drawing.Bitmap($s, $s)
    $g = [System.Drawing.Graphics]::FromImage($bmp)
    $g.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::AntiAlias
    $g.TextRenderingHint = [System.Drawing.Text.TextRenderingHint]::AntiAliasGridFit
    $bg = New-Object System.Drawing.SolidBrush([System.Drawing.Color]::FromArgb(255, 13, 17, 23))
    $g.FillRectangle($bg, 0, 0, $s, $s)
    $w = [Math]::Max(1, [int]($s / 16))
    $pen = New-Object System.Drawing.Pen([System.Drawing.Color]::FromArgb(255, 46, 204, 113)), $w
    $g.DrawRectangle($pen, 1, 1, $s - 2, $s - 2)
    $font = New-Object System.Drawing.Font('Consolas', [float]($s * 0.62), [System.Drawing.FontStyle]::Bold, [System.Drawing.GraphicsUnit]::Pixel)
    $fg = New-Object System.Drawing.SolidBrush([System.Drawing.Color]::FromArgb(255, 46, 204, 113))
    $sf = New-Object System.Drawing.StringFormat
    $sf.Alignment = [System.Drawing.StringAlignment]::Center
    $sf.LineAlignment = [System.Drawing.StringAlignment]::Center
    $g.DrawString('U', $font, $fg, (New-Object System.Drawing.RectangleF(0, 0, $s, $s)), $sf)
    $g.Dispose()
    $bmp.Save($path, [System.Drawing.Imaging.ImageFormat]::Png)
    $bmp.Dispose()
}
Write-Host "[1/4] иконки готовы"

# ---------- 2. .ico для exe ----------
$png = [System.IO.File]::ReadAllBytes((Join-Path $iconDir 'icon128.png'))
$ico = Join-Path $work 'setup.ico'
$fs = [System.IO.File]::Create($ico)
$bw = New-Object System.IO.BinaryWriter($fs)
$bw.Write([UInt16]0); $bw.Write([UInt16]1); $bw.Write([UInt16]1)
$bw.Write([Byte]128); $bw.Write([Byte]128); $bw.Write([Byte]0); $bw.Write([Byte]0)
$bw.Write([UInt16]1); $bw.Write([UInt16]32)
$bw.Write([UInt32]$png.Length); $bw.Write([UInt32]22)
$bw.Write($png)
$bw.Close(); $fs.Close()
Write-Host "[2/4] иконка exe готова"

# ---------- 3. архив расширения ----------
$zip = Join-Path $work 'extension.zip'
if (Test-Path $zip) { Remove-Item $zip -Force }
Compress-Archive -Path (Join-Path $ext '*') -DestinationPath $zip -CompressionLevel Optimal
Write-Host ("[3/4] архив расширения: {0:N1} КБ" -f ((Get-Item $zip).Length / 1KB))

# ---------- 4. компиляция ----------
$csc = Join-Path $env:WINDIR 'Microsoft.NET\Framework64\v4.0.30319\csc.exe'
if (-not (Test-Path $csc)) { $csc = Join-Path $env:WINDIR 'Microsoft.NET\Framework\v4.0.30319\csc.exe' }
if (-not (Test-Path $csc)) { throw 'не найден csc.exe из .NET Framework 4.x' }

$exe = Join-Path $out 'UndoBridge_Setup.exe'
$refs = @(
    '/r:System.dll',
    '/r:System.Core.dll',
    '/r:System.Drawing.dll',
    '/r:System.Windows.Forms.dll',
    '/r:System.IO.Compression.dll',
    '/r:System.IO.Compression.FileSystem.dll'
)

$args = @(
    '/nologo', '/target:winexe', '/platform:anycpu', '/optimize+', '/codepage:65001',
    ('/win32icon:' + $ico),
    ('/out:' + $exe),
    ('/resource:' + $zip + ',UndoBridge.ext.zip')
)

# движок Undo (собранный PyInstaller exe) — чтобы установка не требовала Python
$agent = Join-Path $out 'engine\UndoBridgeAgent.exe'
if (Test-Path $agent) {
    $args += ('/resource:' + $agent + ',UndoBridge.agent.exe')
    Write-Host ("     движок: {0:N1} МБ" -f ((Get-Item $agent).Length / 1MB))
} else {
    Write-Host '     ВНИМАНИЕ: движок не найден, установщик поставит только расширение'
}

$args = $args + $refs + @((Join-Path $inst 'Setup.cs'))

& $csc $args
if ($LASTEXITCODE -ne 0) { throw "компиляция не удалась (код $LASTEXITCODE)" }

Write-Host ("[4/4] готово: {0} ({1:N0} КБ)" -f $exe, ((Get-Item $exe).Length / 1KB))
