/* Undo Bridge — строки интерфейса: en (по умолчанию), ru, zh.
   Используется и в content script (панель на странице), и в popup. */

(function () {
  const DICT = {
    en: {
      wait: "waiting",
      noCmd: "waiting for Undo command",
      copying: "copying the command",
      waitUndo: "Undo is running",
      sending: "sending the answer",
      done: "done",
      paused: "paused",
      resume: "resume",
      once: "run",
      logBtn: "log",
      collapsed: "collapsed",
      step: "step",
      finish: "done, step",
      manual: "manual run",
      stepsReset: "counter reset",
      on: "enabled",
      off: "disabled",
      alreadySent: "command already sent",
      continue: "pressing Continue",
      waitContinue: "waiting for continuation",
      waitAnswer: "waiting for the end of the answer",
      limit: "step limit",
      ready: "ready",
      errBuffer: "could not put the command into the clipboard",
      errUndo: "Undo did not answer",
      errSend: "could not send the answer to the chat",
      errInput: "input field not found",
      errPage: "no code blocks on the page",
      errNotCmd: "the last block is not an Undo command",
      manifestBtn: "insert manifest",
      ctxBtn: "save context",
      insertingManifest: "inserting the manifest",
      savingCtx: "saving the context",
      errManifest: "could not get the manifest from Undo",
      errCtx: "could not get the context from Undo",
      unverified: "clipboard not confirmed, waiting for Undo anyway",
      collapsedTitle: "Undo Bridge"
    },
    ru: {
      wait: "ожидание",
      noCmd: "ожидание команды Undo",
      copying: "копирую команду",
      waitUndo: "Undo выполняет",
      sending: "отправляю ответ",
      done: "готово",
      paused: "пауза",
      resume: "старт",
      once: "раз",
      logBtn: "лог",
      collapsed: "свёрнуто",
      step: "шаг",
      finish: "готово, шаг",
      manual: "ручной запуск",
      stepsReset: "счётчик сброшен",
      on: "включено",
      off: "выключено",
      alreadySent: "команда уже отправлена",
      continue: "нажимаю «Продолжить»",
      waitContinue: "ждём продолжение",
      waitAnswer: "ждём конец ответа",
      limit: "лимит шагов",
      ready: "готов",
      errBuffer: "не удалось положить команду в буфер обмена",
      errUndo: "Undo не ответил",
      errSend: "не удалось отправить ответ в чат",
      errInput: "поле ввода не найдено",
      errPage: "на странице нет блоков кода",
      errNotCmd: "последний блок — не команда Undo",
      manifestBtn: "вставить манифест",
      ctxBtn: "сохранить контекст",
      insertingManifest: "вставляю манифест",
      savingCtx: "сохраняю контекст",
      errManifest: "не удалось получить манифест из Undo",
      errCtx: "не удалось получить контекст из Undo",
      unverified: "буфер не подтверждён, всё равно ждём Undo",
      collapsedTitle: "Undo Bridge"
    },
    zh: {
      wait: "等待",
      noCmd: "等待 Undo 命令",
      copying: "正在复制命令",
      waitUndo: "Undo 执行中",
      sending: "正在发送答案",
      done: "完成",
      paused: "暂停",
      resume: "继续",
      once: "一次",
      logBtn: "日志",
      collapsed: "已收起",
      step: "步骤",
      finish: "完成，步骤",
      manual: "手动运行",
      stepsReset: "计数已重置",
      on: "已启用",
      off: "已停用",
      alreadySent: "命令已发送",
      continue: "按下“继续”",
      waitContinue: "等待继续生成",
      waitAnswer: "等待回答结束",
      limit: "步骤上限",
      ready: "就绪",
      errBuffer: "无法将命令放入剪贴板",
      errUndo: "Undo 未响应",
      errSend: "无法将答案发送到聊天",
      errInput: "未找到输入框",
      errPage: "页面上没有代码块",
      errNotCmd: "最后一个代码块不是 Undo 命令",
      manifestBtn: "插入清单",
      ctxBtn: "保存上下文",
      insertingManifest: "正在插入清单",
      savingCtx: "正在保存上下文",
      errManifest: "无法从 Undo 获取清单",
      errCtx: "无法从 Undo 获取上下文",
      unverified: "剪贴板未确认，仍等待 Undo",
      collapsedTitle: "Undo Bridge"
    }
  };

  const SUPPORTED = ["en", "ru", "zh"];

  function resolve(lang) {
    const code = String(lang || "").toLowerCase();
    if (code.indexOf("zh") === 0) return "zh";
    if (code.indexOf("ru") === 0) return "ru";
    if (code.indexOf("en") === 0) return "en";
    return "en";
  }

  window.UB_I18N = {
    supported: SUPPORTED,
    resolve: resolve,
    dict: DICT,
    /* строки для языка + запасной английский */
    make: function (lang) {
      const code = resolve(lang);
      const table = DICT[code] || DICT.en;
      return function (key) {
        return table[key] || DICT.en[key] || key;
      };
    }
  };
})();
