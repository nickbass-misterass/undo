/* Undo Bridge — offscreen документ.
   Только здесь доступны clipboard API и document.execCommand. */

const buf = document.getElementById("buf");

function legacyWrite(text) {
  try {
    buf.value = text;
    buf.focus();
    buf.select();
    const ok = document.execCommand("copy");
    buf.value = "";
    return !!ok;
  } catch (e) { return false; }
}

function legacyRead() {
  try {
    buf.value = "";
    buf.focus();
    buf.select();
    document.execCommand("paste");
    const v = buf.value;
    buf.value = "";
    return typeof v === "string" ? v : null;
  } catch (e) { return null; }
}

async function writeClip(text) {
  try {
    await navigator.clipboard.writeText(text);
    return true;
  } catch (e) { /* нет фокуса — пробуем legacy */ }
  return legacyWrite(text);
}

async function readClip() {
  try {
    const t = await navigator.clipboard.readText();
    if (typeof t === "string") return t;
  } catch (e) { /* нет фокуса — пробуем legacy */ }
  return legacyRead();
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!msg || msg.to !== "offscreen") return;

  if (msg.cmd === "write") {
    writeClip(String(msg.text == null ? "" : msg.text)).then((ok) => sendResponse({ ok: ok }));
    return true;
  }
  if (msg.cmd === "read") {
    readClip().then((text) => sendResponse({ ok: text !== null, text: text }));
    return true;
  }
  if (msg.cmd === "ping") {
    sendResponse({ ok: true });
    return false;
  }
  return false;
});
